// ============================================================================
// tailwind.config.ts — merge this into your existing theme.extend.
// Lets you use e.g. bg-ink, text-brand-deep, font-display, rounded-xl, shadow-brand.
// ============================================================================
import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: "#5ba4f5",
          50: "#eef5fe", 100: "#d7e9fd", 200: "#b4d5fb", 300: "#8fc0f8",
          400: "#6faef6", 500: "#5ba4f5", 600: "#3d8de8", 700: "#2e74c9",
          deep: "#2e74c9",
        },
        ink: "#0f172a",
        dark: { DEFAULT: "#0b1120", 2: "#111a2e" },
        hairline: "#e7ebf0",
      },
      fontFamily: {
        // pairs with the next/font CSS variables from layout.tsx
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      borderRadius: {
        sm: "8px", md: "12px", lg: "16px", xl: "22px",
      },
      boxShadow: {
        sm: "0 1px 2px rgba(15,23,42,.04),0 1px 3px rgba(15,23,42,.06)",
        md: "0 4px 12px rgba(15,23,42,.06),0 12px 28px rgba(15,23,42,.08)",
        lg: "0 12px 24px rgba(15,23,42,.08),0 30px 60px rgba(15,23,42,.12)",
        "2xl": "0 25px 50px -12px rgba(15,23,42,.25)",
        brand: "0 10px 30px rgba(91,164,245,.22)",
      },
      maxWidth: { container: "1180px" },
    },
  },
  plugins: [],
};

export default config;
