// ============================================================================
// apps/web/src/app/layout.tsx — three-font stack wiring
// Replace the existing single-Inter setup with this.
// ============================================================================
import type { Metadata } from "next";
import { Inter, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-body",
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-display",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Yippie — Your growth partner in customer service",
  description:
    "Yippie auto-drafts every support ticket from your inbox. Inbox, tickets, contacts, calendar and live chat in one platform — with unlimited contacts on every plan.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${spaceGrotesk.variable} ${jetbrainsMono.variable}`}
    >
      {/* body uses Inter; headings opt into var(--font-display), eyebrows/meta into var(--font-mono) */}
      <body style={{ fontFamily: "var(--font-body)" }}>{children}</body>
    </html>
  );
}
