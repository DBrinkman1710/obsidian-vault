# Design Handoff — Yippie brand refresh (sandbox)

## Overview
This package contains the refreshed **Yippie** brand and marketing site, rebuilt against the `sandbox` branch direction: a "premium-light tech" system with a three-font type stack, an **ink primary button that warms to Yippie blue on hover**, faint tech-grid/dot textures, the new **clock-to-network logo**, a first-person founder voice, and a real multi-page marketing site (Home · Product · Pricing · About · Blog).

The goal of this handoff is to **apply these decisions to the live Next.js site** at `apps/web` on the `sandbox` branch — not to ship the HTML in this folder as-is.

## About the design files
The files in `prototype/` are **design references created in HTML** (React rendered via in-browser Babel, composing a compiled design-system bundle). They are prototypes showing the intended look, copy, and behavior — **not production code to copy directly**.

Your task is to **recreate these designs in the existing `apps/web` environment** (Next.js 14 App Router + Tailwind v3) using its established patterns: Server/Client components, `next/font/google`, Tailwind classes / CSS variables in `globals.css`, and `lucide-react`. Most changes map onto files that already exist (see **File mapping** below).

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, shadows, copy, and interactions are final. Recreate pixel-faithfully using the codebase's existing libraries. Exact token values are in **Design tokens** below and ready-to-paste snippets are in `snippets/`.

---

## File mapping (where each change lands in apps/web)

| Change | Target file(s) in `apps/web` |
|---|---|
| Color + radius + shadow tokens, texture helpers, scroll-reveal | `src/app/globals.css` — see `snippets/globals.css` |
| Three-font stack (Space Grotesk + Inter + JetBrains Mono) | `src/app/layout.tsx` — see `snippets/layout.tsx` |
| Tailwind theme extension (brand/ink/fonts) | `tailwind.config.ts` — see `snippets/tailwind.config.snippet.ts` |
| New logo (mark-only header, full lockup footer) | already in repo `Logo files/`; copy into `apps/web/public/` |
| Home page | `src/app/page.tsx` |
| Product/modules page | `src/app/modules/page.tsx` |
| Pricing page (config-driven) | `src/app/pricing/page.tsx` + `src/lib/config.ts` (already correct) |
| About page (first-person founder story) | `src/app/about/page.tsx` |
| Blog index | `src/app/blog/page.tsx` |
| Shared nav/footer | `src/app/components/SiteNav.tsx` + footer component |

---

## Design tokens

### Type — three families (all `next/font/google`)
- **Space Grotesk** (500/600/700) → display & headings. CSS var `--font-display`. Tracking −0.025 to −0.03em.
- **Inter** (400–700) → body & UI. `--font-body`. Body line-height 1.7 on marketing.
- **JetBrains Mono** (500/600) → eyebrows, meta, IDs, URLs, the hero pill. `--font-mono`. Eyebrows render with a `// ` prefix, e.g. `// Features`.

Type scale (px): display clamp→70 / h1 44 / h2 32 / app title 26 / h3 17 / lead 18 / base 16 / sm 14 (UI default) / mono-eyebrow 12–13.

### Color
**One brand blue over Tailwind slate. Primary action is ink, not blue.**

| Token | Hex | Use |
|---|---|---|
| `--brand` / yippie-500 | `#5BA4F5` | THE blue: links, eyebrows, stat numbers, active, focus ring, app sidebar, primary-button **hover** |
| yippie-600 | `#3D8DE8` | hover deepen |
| yippie-700 / `--brand-deep` | `#2E74C9` | blue text/eyebrows on light |
| yippie-50 | `#EEF5FE` | tinted chips/surfaces |
| `--ink` | `#0F172A` | **primary button bg + headings**; warms to `--brand` on hover |
| Neutrals | Tailwind slate `#F8FAFC`→`#0F172A` | 700 body, 500/400 muted/meta |
| `--border-default` | `#E7EBF0` | hairline 1px border |
| `--off-white` | `#F8FAFC` | section bands |
| `--dark` | `#0B1120` | dark product-moment sections + footer |
| `--dark-2` | `#111A2E` | secondary dark surface |

Status (fg / tint bg): urgent `#DC2626`/`#FEF2F2` · high `#D97706`/`#FFF7ED` · success `#16A34A`/`#ECFDF5` · info `#3B82F6`/`#EFF6FF` · waiting `#7C3AED`/`#F5F3FF`.

Brand tints (rgba 91,164,245): soft .10 · soft-2 .16 · ring .30 · glow .18.

### Radii
sm 8 (buttons/inputs/rows) · md 12 (cards) · lg 16 (product frame) · xl 22 (CTA cards) · full 999 (pills/avatars/toggles).

### Shadows (cool, slate-tinted `rgba(15,23,42,…)`, layered — no glow)
- sm: `0 1px 2px /.04, 0 1px 3px /.06`
- md (hover): `0 4px 12px /.06, 0 12px 28px /.08`
- lg: `0 12px 24px /.08, 0 30px 60px /.12`
- 2xl (mockups): `0 25px 50px -12px /.25`
- brand (lifted primary button): `0 10px 30px rgba(91,164,245,.22)`
- focus ring: `0 0 0 3px rgba(91,164,245,.30)`

### Spacing
4px grid. Marketing sections pad ~96px vertical, gutter `6vw`, max width 1180px. App content pads 32px; sidebar 220px.

### Textures (the signature "tech" motif)
- `.bgGrid` — slate grid, 56px: `linear-gradient(to right, rgba(15,23,42,.035) 1px, transparent 1px)` + same `to bottom`, `background-size: 56px 56px`.
- `.bgDots` — slate dot field, 24px: `radial-gradient(circle at 1px 1px, rgba(15,23,42,.05) 1px, transparent 0)`, `24px 24px`.
- `.bgDotsDark` — same with `rgba(255,255,255,.05)` over dark sections, plus one soft blurred Yippie-blue radial glow.
- No photography, illustration, or gradients (one exception: the CTA card's faint radial blue wash).

---

## Components & states
- **Button (primary):** bg `--ink`, text white, radius 8. **Hover:** bg → `--brand`, `translateY(-2px)`, shadow `--shadow-brand`. Press: translateY(0). This ink→blue lift is the signature interaction — do not default primaries to solid blue.
  - Secondary: white bg, `--border-default`; hover border → `--brand` + lift. Ghost: transparent, slate wash on hover. Danger: `#DC2626`.
- **Eyebrow:** JetBrains Mono 12–13/600, `--brand-deep` (bright `--brand` on dark), `// ` prefix.
- **Card:** white, 1px `--border-default`, `--shadow-sm`; hover → `--shadow-md` + translateY(-3px). Featured pricing card: 1.5px `--brand` ring + ink "Most popular" pill.
- **Stat:** Space Grotesk clamp 38–52/700, `--brand-deep`, over a slate label.
- **Badge:** full-pill, soft tinted bg + full-strength status fg; optional leading dot.
- **Focus:** `--brand` border + 3px `rgba(91,164,245,.30)` ring.
- **Scroll-reveal:** fade + 14px rise, `0.6s cubic-bezier(0.22,1,0.36,1)`, stagger ~70–90ms; must degrade to visible for reduced-motion/print.
- **Icons:** lucide, stroke 1.6–2, `currentColor`.

---

## Pages

### Home (`page.tsx`)
Hero (mark watermark behind, off to the left ~14%, ~8.5% opacity, both clock + network visible) → trust logo strip → 3-stat band → Features (6, two-col with icon tiles) → How it works (3 steps) → dark "everything in one place" product moment (light browser mockup of the inbox with a blue mini-sidebar) → Growth Partner ("When you grow, I grow.") → pricing teaser (€9/€19/€49, links to /pricing) → CTA. Nav brand = **mark only**; footer brand = **full lockup, large**.

### Product (`modules/page.tsx`)
Hero "Ten modules. One platform." → sticky module sub-nav (jump chips) → 10 alternating feature blocks (Inbox, Tickets, Contacts, Calendar+Booking, Pipeline, Live Chat, Email tracking, Templates, Activity, Team), each with a branded preview frame → dark CTA.

### Pricing (`pricing/page.tsx`, config-driven from `lib/config.ts`)
Monthly/Annual toggle (annual −10%). Plans: **Founder €9/mo (€97/yr)**, **Starter €19 (€205)**, **Growth €49 (€529, Most popular)**, **Enterprise Custom**. Every plan lists exactly 6 rows so cards are equal height. Add-ons grid: Tickets €15 · AI €19 · Calendar+Booking €12 · Kanban €12 · Email tracking €9 (per workspace/mo). FAQ (4, accordion). CTA.

### About (`about/page.tsx`) — first person
Founder: **Diederik Brinkman**, industrial engineer fascinated by optimising things. Frontline roles: **Bol.com** (high-volume consumer support), **HeatTransformers** (heat-pump installation planning), **Medspace** (scheduling software for hospital departments). The recurring problem: two extremes — **shared-mailbox chaos** vs. **enterprise bloat** (Zoho/Atlassian). Thesis: "I knew I could build better — so I did." Philosophy: easy to learn (≤5 min), pay for what you use (à la carte), grows with you (unlimited contacts). *(Headshot pending — currently an initials avatar.)*

### Blog (`blog/page.tsx`)
3-card index (placeholder posts — replace with real content). Cards: tag chip, title, excerpt, date · read time.

---

## Voice
Warm, direct, benefit-first. **First person — "I / my"** (solo founder), product referred to as "Yippie." Sentence case everywhere; the only non-sentence type is the mono `// ` eyebrow. No emoji. Concrete modest proof (10h+/week, <2 min). CTAs: "Request demo →", "Start growing with us →".

⚠️ **Apostrophes:** use real `'` (or `&rsquo;`) in copy — an earlier bug rendered literal `\u2019`. Don't reintroduce escape sequences in JSX text.

---

## Assets
- New **clock-to-network logo** (clock hands blooming into a connected-node constellation + lowercase `yippie` wordmark + "CUSTOMER PLATFORM" tagline). In repo at `Logo files/`. Variants in `prototype/assets/`: background tiles (white/ink/blue, svg+png), transparent lockups (`logo-lockup-onLight/onDark`), tight nav crops (`logo-nav-*`), mark-only (`logo-mark-tight`, `logo-mark-*`), `favicon.svg`.
- Header uses the **mark only** (`logo-mark-tight`); footer uses the **full lockup** large; the hero background watermark uses `logo-mark-tight` at ~8.5% opacity.
- Icons: **lucide-react** (already a brand standard).

## Files in this package
- `README.md` — this marketing spec. **`APP.md` — the support-app spec (shell, multi-select system, right-click menu, all screens).**
- `snippets/globals.css` — paste-ready token block, textures, scroll-reveal.
- `snippets/layout.tsx` — the three `next/font/google` imports + body class wiring.
- `snippets/tailwind.config.snippet.ts` — theme.extend for colors/fonts/radii.
- `prototype/marketing/` — the full HTML/JSX reference site.
- `prototype/app/` — the full runnable support-app reference (sign-in → all modules). Reusables to port first: `Selection.jsx`, `ContextMenu.jsx`.
- `prototype/assets/` — all logo variants + favicon.

A developer who wasn't in this conversation should be able to implement the refresh from this README plus the snippets and prototype files.
