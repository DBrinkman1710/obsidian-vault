# Design Handoff — Yippie Support App (in-app UI)

Companion to the marketing handoff (`README.md`). Covers the **support platform** at `app.getyippie.com` — recreate these in the existing `apps/app/frontend` (React + Vite) using the brand tokens from `snippets/globals.css` and `lucide-react`.

The HTML in `prototype/app/` is a **design reference**, not production code. Lift exact values, structure, and behavior into your real components.

---

## Shell

### Sidebar (`shell/Sidebar.tsx`)
- Fixed **220px**, full-height, solid **Yippie blue** (`--brand` #5BA4F5), sticky.
- **Workspace header** = a **white rounded tile (44px, radius 12, soft shadow)** holding the colored clock-network **mark only** (no wordmark — it's invisible against the blue otherwise), with "Yippie" (Space Grotesk 700, white) + workspace name ("Acme BV", white 70%) beside it.
- Nav items: 14px, radius 12, icon (lucide, stroke 2) + label; **active** = `rgba(255,255,255,0.20)` bg + white text; idle = white 75%. Count badges: white pill w/ brand-deep text (neutral), red pill (urgent), green pill (chat). Green status dot on Inbox.
- Items: Inbox · Contacts · Tickets · Calendar · Live Chat · Activity · Billing. Footer group: Profile · Settings, user email, Sign out.

### Login (`auth/Login.tsx`)
- Centered on the `.bgGrid` off-white background. The **full logo lockup sits ABOVE the card** (not inside it), large (~132px tall).
- Card: 400px, white, radius 16, `--shadow-lg`. Mono `// Sign in` eyebrow → "Welcome back" (Space Grotesk 700) → Inputs (email/password w/ leading lucide icon) → full-width primary Button.

### Page header (shared)
- Title: Space Grotesk **26/700**, ink, −0.02em. Optional subtitle (slate-500, 14). Optional right-aligned action Button.

---

## Lists & the multi-select system  ⭐ (core interaction)

**Every list is multi-selectable** — inbox, contacts, tickets, billing, live chat. Implement once, reuse everywhere (see `prototype/app/Selection.jsx`).

- **`useSelection(ids)`** → `{ has(id), toggle(id,e), toggleAll(), clear(), count, all, some }`. Selection survives filtering/search (drops ids no longer present).
- **`Checkbox`** — 18px, radius 5. **Built as an inline SVG** (`<rect>` + check `<path>`), NOT a CSS-background box: brand fill `#5BA4F5` + white check when checked, white + slate-300 stroke when idle, a white dash when indeterminate. ⚠️ Building it with `background` was unreliable under the cascade — keep it SVG-based (or guarantee the fill another way).
- **Select-all** — a header checkbox; shows the **indeterminate dash** when some-but-not-all are selected.
- **`BulkBar`** — appears above the list when `count > 0`: an **ink** (#0F172A) rounded bar, mono "N selected", a divider, then contextual action buttons (icon + label; danger actions get a red bg), and a "× Clear" on the right.
- **Selected-row affordance** = a soft **`--brand-soft`** tint on the row/card. **No border highlight** (a brand/dark border read as an ugly outline — avoid it).

**Per-list bulk actions:**
| List | Actions |
|---|---|
| Inbox | Approve · Forward · Reject (danger) |
| Tickets | Assign · Resolve · Close · Delete (danger) |
| Contacts | Add label · Add to pipeline · Export · Delete (danger) |
| Billing | Send reminder · Mark paid · Export · Delete (danger) |
| Live Chat | Assign · Resolve · Mark read · Delete (danger) |

---

## Right-click context menu (`prototype/app/ContextMenu.jsx`)

Themed menu on **right-click of any list row**. `useContextMenu()` → `{ state, open(e, items), close() }`; render `<ContextMenu state onClose />` once per view.

- Surface: white, radius 12, 1px hairline border, `--shadow-lg`, min-width 208, 6px padding. Opens at the cursor, **clamps to the viewport**, 90ms scale+fade in. Closes on outside-click, second right-click, Esc, or scroll.
- Item: 13.5px, radius 8, lucide icon (slate → **brand-deep on hover**, row bg → `--brand-soft`). Supports `header` (mono uppercase caption, e.g. the sender/record name), `separator`, `shortcut` (mono, right-aligned), and `danger` (red text, red-tint hover).
- Example items per row mirror the bulk actions plus row-specific ones (Review draft, Open ticket, View contact, View invoice, Duplicate, Download PDF, etc.).

---

## Screens

- **Inbox** (`modules/inbox/`) — Pending/Processed tabs; AI-draft cards (source icon, subject, priority + category badges, AI summary, sender · time, **Review** button). **Whole card is clickable** → Draft Review. Hover lifts the card (keep this hover effect). Per-card checkbox + right-click menu.
- **Draft Review** — two columns: original message (left) vs **AI-drafted ticket** (right, brand-tinted border, `sparkles` eyebrow) with editable subject / priority pills / category / description and Approve · Forward · Reject actions.
- **Tickets** — status `Select` filter; cards with subject, dept badge, last-activity line, status badge, priority (status color) + date. Checkbox + menu.
- **Contacts** — search; table (avatar + name link, email, company, phone). Select-all header checkbox + per-row checkbox; row menu.
- **Calendar** (`modules/calendar/`) — month grid with color-coded events (info/success/high/waiting tints) + today highlight, and an "// Upcoming" rail of the next bookings.
- **Live Chat** (`modules/chat/`) — two-pane: session list (avatar, name, last msg, status badge, unread pill; checkbox + select-all header) ↔ conversation (brand outgoing bubbles, off-white thread, composer + Send).
- **Billing** (`modules/billing/`) — invoice table (mono invoice id, client, amount, status badge, due/paid). Select-all + per-row checkbox; row menu.

---

## Tokens & icons
Same brand tokens as the marketing handoff (`snippets/globals.css` / `tailwind.config.snippet.ts`). App surfaces favor radius 8–12 and `--shadow-sm`. Icons: **lucide-react**, stroke ~2 at 16. Status colors: urgent/red, high/amber, info/blue, success/green, waiting/violet (fg + soft tinted bg pairs).

## Files
- `prototype/app/` — full runnable reference (sign-in → all modules).
- Key reusables to port first: `Selection.jsx` (useSelection + Checkbox + BulkBar) and `ContextMenu.jsx` (useContextMenu + ContextMenu).
