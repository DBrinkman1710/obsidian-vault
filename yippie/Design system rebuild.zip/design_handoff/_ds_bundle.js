/* @ds-bundle: {"format":3,"namespace":"YippieDesign_488656","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Stat","sourcePath":"components/core/Stat.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Toggle","sourcePath":"components/forms/Toggle.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"f9bdaba17e5b","components/core/Badge.jsx":"500aa85a0db9","components/core/Button.jsx":"01d8af21feeb","components/core/Card.jsx":"aacbe9eb5727","components/core/Eyebrow.jsx":"be5e38994988","components/core/IconButton.jsx":"25128814bcac","components/core/Stat.jsx":"e5acd74f89a1","components/forms/Input.jsx":"0fe742b49a5c","components/forms/Select.jsx":"9b6fca92204c","components/forms/Toggle.jsx":"e1679440cdd9","components/navigation/Tabs.jsx":"cb659c23efc3","ui_kits/app/Inbox.jsx":"5fceb059a362","ui_kits/app/Records.jsx":"8a6fec4c92d2","ui_kits/app/Shell.jsx":"b0650ad720dd","ui_kits/app/icons.jsx":"4eeadbea71f1","ui_kits/marketing/Content.jsx":"15a988e11706","ui_kits/marketing/Hero.jsx":"a70ee82ebb28","ui_kits/marketing/Nav.jsx":"7cec64f806e2","ui_kits/marketing/Pricing.jsx":"b455d42b796c","ui_kits/marketing/icons.jsx":"4eeadbea71f1"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.YippieDesign_488656 = window.YippieDesign_488656 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
/**
 * Yippie Avatar — initials circle (the inbox rows' sender mark).
 */
function Avatar({
  name = '?',
  size = 32,
  tone = 'slate',
  src = null,
  style = {}
}) {
  const initials = name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  const tones = {
    slate: {
      bg: 'var(--slate-200)',
      fg: 'var(--slate-600)'
    },
    brand: {
      bg: 'var(--brand-subtle)',
      fg: 'var(--yippie-700)'
    },
    dark: {
      bg: 'var(--slate-700)',
      fg: 'var(--slate-300)'
    }
  };
  const t = tones[tone] || tones.slate;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      flexShrink: 0,
      borderRadius: 'var(--radius-full)',
      background: src ? `center/cover url(${src})` : t.bg,
      color: t.fg,
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-bold)',
      fontSize: Math.round(size * 0.4),
      lineHeight: 1,
      overflow: 'hidden',
      ...style
    }
  }, src ? null : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  neutral: {
    bg: 'var(--surface-sunken)',
    fg: 'var(--slate-600)'
  },
  brand: {
    bg: 'var(--brand-subtle)',
    fg: 'var(--yippie-700)'
  },
  urgent: {
    bg: 'var(--status-urgent-bg)',
    fg: 'var(--status-urgent)'
  },
  high: {
    bg: 'var(--status-high-bg)',
    fg: 'var(--status-high)'
  },
  success: {
    bg: 'var(--status-success-bg)',
    fg: 'var(--status-success)'
  },
  info: {
    bg: 'var(--status-info-bg)',
    fg: 'var(--status-info)'
  },
  waiting: {
    bg: 'var(--status-waiting-bg)',
    fg: 'var(--status-waiting)'
  }
};

/**
 * Yippie Badge — pill label for status, priority, category & counts.
 * Soft tinted background with full-strength text (the app's status convention).
 */
function Badge({
  children,
  tone = 'neutral',
  dot = false,
  style = {},
  ...rest
}) {
  const t = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '2px 9px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--weight-semibold)',
      lineHeight: 1.5,
      borderRadius: 'var(--radius-full)',
      background: t.bg,
      color: t.fg,
      whiteSpace: 'nowrap',
      textTransform: 'capitalize',
      ...style
    }
  }, rest), dot ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: t.fg
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Yippie Button — the primary action control.
 * Brand-blue solid, slate outline, or ghost. Inter semibold, soft rounded-xl.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  icon = null,
  iconRight = null,
  disabled = false,
  fullWidth = false,
  type = 'button',
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '8px 14px',
      fontSize: 'var(--text-xs)',
      radius: 'var(--radius-lg)',
      gap: 6,
      icon: 14
    },
    md: {
      padding: '10px 18px',
      fontSize: 'var(--text-sm)',
      radius: 'var(--radius-xl)',
      gap: 8,
      icon: 16
    },
    lg: {
      padding: '14px 24px',
      fontSize: 'var(--text-base)',
      radius: 'var(--radius-xl)',
      gap: 8,
      icon: 18
    }
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    primary: {
      background: 'var(--brand)',
      color: 'var(--text-on-brand)',
      border: '1px solid transparent'
    },
    secondary: {
      background: 'var(--surface-card)',
      color: 'var(--slate-700)',
      border: '1px solid var(--border-default)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--slate-600)',
      border: '1px solid transparent'
    },
    danger: {
      background: 'var(--red-600)',
      color: 'var(--white)',
      border: '1px solid transparent'
    }
  };
  const v = variants[variant] || variants.primary;
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const hoverStyle = !disabled && hover ? variant === 'secondary' ? {
    borderColor: 'var(--border-strong)'
  } : variant === 'ghost' ? {
    background: 'var(--surface-sunken)'
  } : {
    opacity: 0.9
  } : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : 'auto',
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      padding: s.padding,
      fontFamily: 'var(--font-sans)',
      fontSize: s.fontSize,
      fontWeight: 'var(--weight-semibold)',
      lineHeight: 1,
      borderRadius: s.radius,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.55 : 1,
      transform: active && !disabled ? 'translateY(0.5px)' : 'none',
      transition: 'opacity 150ms ease, border-color 150ms ease, background 150ms ease, transform 80ms ease',
      whiteSpace: 'nowrap',
      ...v,
      ...hoverStyle,
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      width: s.icon,
      height: s.icon
    }
  }, icon) : null, children, iconRight ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      width: s.icon,
      height: s.icon
    }
  }, iconRight) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Yippie Card — white surface with hairline slate border.
 * `pad` controls inner padding; `radius` 'lg' (app) or 'xl'/'2xl' (marketing).
 */
function Card({
  children,
  pad = 20,
  radius = 'lg',
  hoverable = false,
  featured = false,
  style = {},
  ...rest
}) {
  const radii = {
    lg: 'var(--radius-lg)',
    xl: 'var(--radius-xl)',
    '2xl': 'var(--radius-2xl)'
  };
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => hoverable && setHover(true),
    onMouseLeave: () => hoverable && setHover(false),
    style: {
      background: 'var(--surface-card)',
      border: featured ? '2px solid var(--brand)' : '1px solid var(--border-default)',
      borderRadius: radii[radius] || radii.lg,
      padding: pad,
      boxShadow: hover ? 'var(--shadow-md)' : 'var(--shadow-sm)',
      transition: 'box-shadow 200ms ease',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
/**
 * Yippie Eyebrow — the uppercase, wide-tracked section kicker
 * ("Features", "Pricing", "How it works"). Brand-blue or muted slate.
 */
function Eyebrow({
  children,
  tone = 'brand',
  style = {}
}) {
  const color = tone === 'brand' ? 'var(--brand)' : 'var(--text-muted)';
  return /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: 'var(--tracking-widest)',
      textTransform: 'uppercase',
      color,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Yippie IconButton — square, icon-only control for toolbars & rows.
 */
function IconButton({
  children,
  label,
  variant = 'ghost',
  size = 'md',
  disabled = false,
  onClick,
  style = {},
  ...rest
}) {
  const dims = {
    sm: 30,
    md: 36,
    lg: 42
  }[size] || 36;
  const variants = {
    ghost: {
      background: 'transparent',
      color: 'var(--slate-500)',
      border: '1px solid transparent'
    },
    outline: {
      background: 'var(--surface-card)',
      color: 'var(--slate-600)',
      border: '1px solid var(--border-default)'
    },
    solid: {
      background: 'var(--brand)',
      color: 'var(--white)',
      border: '1px solid transparent'
    }
  };
  const v = variants[variant] || variants.ghost;
  const [hover, setHover] = React.useState(false);
  const hoverStyle = !disabled && hover ? variant === 'solid' ? {
    opacity: 0.9
  } : {
    background: 'var(--surface-sunken)',
    color: 'var(--slate-700)'
  } : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: dims,
      height: dims,
      borderRadius: 'var(--radius-lg)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'background 150ms ease, color 150ms ease, opacity 150ms ease',
      ...v,
      ...hoverStyle,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Stat.jsx
try { (() => {
/**
 * Yippie Stat — oversized brand-blue metric over a slate label.
 * The marketing "10h+ saved per week" pattern.
 */
function Stat({
  value,
  label,
  align = 'center',
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: align,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-display)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--tracking-tight)',
      lineHeight: 1,
      color: 'var(--brand)',
      marginBottom: 12
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-subtle)',
      lineHeight: 'var(--leading-relaxed)'
    }
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stat.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Yippie Input — labeled text field. Slate border, brand-blue focus.
 */
function Input({
  label,
  hint,
  error,
  required = false,
  icon = null,
  type = 'text',
  size = 'md',
  style = {},
  containerStyle = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const pad = size === 'lg' ? '12px 14px' : '10px 12px';
  const borderColor = error ? 'var(--red-500)' : focus ? 'var(--brand)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)',
      ...containerStyle
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--slate-600)'
    }
  }, label, required ? ' *' : '') : null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: pad,
      background: 'var(--surface-card)',
      border: `1px solid ${borderColor}`,
      borderRadius: 'var(--radius-xl)',
      boxShadow: focus && !error ? 'var(--ring-brand)' : 'none',
      transition: 'border-color 150ms ease, box-shadow 150ms ease'
    }
  }, icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      color: 'var(--slate-400)'
    }
  }, icon) : null, /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'inherit',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-heading)',
      ...style
    }
  }, rest))), error ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--red-600)'
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Yippie Select — native dropdown styled to match Input.
 */
function Select({
  label,
  options = [],
  value,
  onChange,
  required = false,
  style = {},
  containerStyle = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)',
      ...containerStyle
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--slate-600)'
    }
  }, label, required ? ' *' : '') : null, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      border: `1px solid ${focus ? 'var(--brand)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-xl)',
      background: 'var(--surface-card)',
      boxShadow: focus ? 'var(--ring-brand)' : 'none',
      transition: 'border-color 150ms ease, box-shadow 150ms ease'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: 'none',
      WebkitAppearance: 'none',
      width: '100%',
      padding: '10px 36px 10px 12px',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'inherit',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-heading)',
      cursor: 'pointer',
      ...style
    }
  }, rest), options.map(o => {
    const val = typeof o === 'string' ? o : o.value;
    const lbl = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: val,
      value: val
    }, lbl);
  })), /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--slate-400)",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      position: 'absolute',
      right: 12,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  }))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Toggle.jsx
try { (() => {
/**
 * Yippie Toggle — pill switch (the marketing monthly/annual billing toggle).
 */
function Toggle({
  checked = false,
  onChange,
  disabled = false,
  label,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": checked,
    disabled: disabled,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      position: 'relative',
      width: 44,
      height: 24,
      flexShrink: 0,
      borderRadius: 'var(--radius-full)',
      border: 'none',
      background: checked ? 'var(--brand)' : 'var(--slate-200)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'background 180ms ease',
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      left: 2,
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: 'var(--white)',
      boxShadow: 'var(--shadow-sm)',
      transform: checked ? 'translateX(20px)' : 'translateX(0)',
      transition: 'transform 180ms ease'
    }
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      color: 'var(--slate-700)'
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Toggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Toggle.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
/**
 * Yippie Tabs — pill segmented control (the inbox Pending/Processed tabs).
 */
function Tabs({
  tabs = [],
  value,
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      gap: 8,
      ...style
    }
  }, tabs.map(t => {
    const val = typeof t === 'string' ? t : t.value;
    const lbl = typeof t === 'string' ? t : t.label;
    const count = typeof t === 'object' ? t.count : undefined;
    const active = val === value;
    return /*#__PURE__*/React.createElement("button", {
      key: val,
      type: "button",
      onClick: () => onChange && onChange(val),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 7,
        padding: '7px 16px',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--text-sm)',
        fontWeight: 'var(--weight-semibold)',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid transparent',
        background: active ? 'var(--brand)' : 'var(--surface-sunken)',
        color: active ? 'var(--white)' : 'var(--slate-600)',
        cursor: 'pointer',
        transition: 'background 150ms ease, color 150ms ease'
      }
    }, lbl, count != null ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-2xs)',
        fontWeight: 'var(--weight-bold)',
        padding: '1px 6px',
        borderRadius: 'var(--radius-full)',
        background: active ? 'rgba(255,255,255,0.25)' : 'var(--slate-200)',
        color: active ? 'var(--white)' : 'var(--slate-500)'
      }
    }, count) : null);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Inbox.jsx
try { (() => {
const {
  Tabs,
  Badge,
  Button,
  Card
} = window.YippieDesign_488656;
const {
  Icon,
  PageHeader
} = window;
const DRAFTS = [{
  id: 'd1',
  source: 'email',
  subject: 'Invoice INV-0421 — overcharged?',
  priority: 'high',
  tone: 'high',
  category: 'Billing',
  when: '4m ago',
  desc: 'Customer says invoice INV-0421 charged €240 instead of the agreed €180 and is asking for a corrected invoice before paying.',
  from: 'finance@acmebv.com',
  name: 'Acme BV',
  body: "Hi,\n\nWe just received invoice INV-0421 for €240, but our agreed monthly rate is €180. Could you please send a corrected invoice? We'll settle it the same day.\n\nThanks,\nLotte — Acme BV"
}, {
  id: 'd2',
  source: 'whatsapp',
  subject: 'Login issue — account locked',
  priority: 'urgent',
  tone: 'urgent',
  category: 'Account',
  when: '12m ago',
  desc: 'User locked out after multiple failed login attempts, needs urgent access to pull a report for a client meeting in an hour.',
  from: '+31 6 1234 5678',
  name: 'TechCorp',
  body: "Hi! I'm locked out of my account after a few wrong password tries. I have a client meeting in an hour and need a report. Can you unlock me asap?"
}, {
  id: 'd3',
  source: 'email',
  subject: 'Pricing plan upgrade to Growth',
  priority: 'low',
  tone: 'neutral',
  category: 'Sales',
  when: '1h ago',
  desc: 'Existing Starter customer wants to upgrade to the Growth plan and asks whether annual billing is available.',
  from: 'ops@nordex.io',
  name: 'Nordex',
  body: "Hello, we'd like to move from Starter to Growth. Is annual billing available, and would the −20% apply immediately?"
}];
const SOURCE_ICON = {
  email: 'mail',
  whatsapp: 'message-circle'
};
function InboxQueue({
  openDraft
}) {
  const [tab, setTab] = React.useState('pending');
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Inbox",
    subtitle: "Messages from email and WhatsApp \u2014 review AI drafts before creating tickets."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    tabs: [{
      value: 'pending',
      label: 'Pending',
      count: 3
    }, {
      value: 'processed',
      label: 'Processed'
    }]
  })), tab === 'processed' ? /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 14,
      padding: '20px 0'
    }
  }, "No processed drafts yet today.") : DRAFTS.map(d => /*#__PURE__*/React.createElement(Card, {
    key: d.id,
    pad: 0,
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      padding: '16px 20px',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: SOURCE_ICON[d.source],
    size: 15
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      color: 'var(--text-heading)',
      fontSize: 15
    }
  }, d.subject), /*#__PURE__*/React.createElement(Badge, {
    tone: d.tone
  }, d.priority), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, d.category)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 4px',
      fontSize: 13,
      color: 'var(--text-subtle)',
      lineHeight: 'var(--leading-relaxed)'
    }
  }, d.desc), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, d.name, " \xB7 ", d.when)), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "primary",
    onClick: () => openDraft(d.id),
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 14
    })
  }, "Review")))));
}
function DraftReview({
  id,
  back
}) {
  const d = DRAFTS.find(x => x.id === id) || DRAFTS[0];
  const [priority, setPriority] = React.useState(d.priority);
  const priorities = ['low', 'medium', 'high', 'urgent'];
  const ptone = {
    low: 'neutral',
    medium: 'info',
    high: 'high',
    urgent: 'urgent'
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("button", {
    onClick: back,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      border: 'none',
      background: 'transparent',
      color: 'var(--text-subtle)',
      cursor: 'pointer',
      fontSize: 13,
      fontWeight: 600,
      fontFamily: 'var(--font-sans)',
      padding: 0,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-left",
    size: 16
  }), " Back to inbox"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 20,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    pad: 20
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: SOURCE_ICON[d.source],
    size: 16,
    color: "var(--text-subtle)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, "Original message")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--text-heading)'
    }
  }, d.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      marginBottom: 14
    }
  }, d.from), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      color: 'var(--text-body)',
      lineHeight: 'var(--leading-relaxed)',
      whiteSpace: 'pre-wrap'
    }
  }, d.body)), /*#__PURE__*/React.createElement(Card, {
    pad: 20,
    style: {
      borderColor: 'var(--yippie-200)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      color: 'var(--brand)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sparkles",
    size: 16
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--brand)'
    }
  }, "AI-drafted ticket")), /*#__PURE__*/React.createElement(Field, {
    label: "Subject"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--text-heading)'
    }
  }, d.subject)), /*#__PURE__*/React.createElement(Field, {
    label: "Priority"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, priorities.map(p => /*#__PURE__*/React.createElement("button", {
    key: p,
    onClick: () => setPriority(p),
    style: {
      padding: '4px 10px',
      borderRadius: 'var(--radius-full)',
      fontSize: 12,
      fontWeight: 600,
      cursor: 'pointer',
      textTransform: 'capitalize',
      fontFamily: 'var(--font-sans)',
      border: priority === p ? '1px solid transparent' : '1px solid var(--border-default)',
      background: priority === p ? 'var(--brand)' : 'var(--surface-card)',
      color: priority === p ? 'var(--white)' : 'var(--text-subtle)'
    }
  }, p)))), /*#__PURE__*/React.createElement(Field, {
    label: "Category"
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, d.category)), /*#__PURE__*/React.createElement(Field, {
    label: "Description"
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      color: 'var(--text-body)',
      lineHeight: 'var(--leading-relaxed)'
    }
  }, d.desc)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 20,
      paddingTop: 16,
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "check",
      size: 16
    }),
    onClick: back
  }, "Approve & create ticket"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: back
  }, "Forward"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: back
  }, "Reject")))));
}
function Field({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--slate-500)',
      marginBottom: 6
    }
  }, label), children);
}
Object.assign(window, {
  InboxQueue,
  DraftReview
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Inbox.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Records.jsx
try { (() => {
const {
  Badge,
  Button,
  Select,
  Input,
  Card,
  Avatar
} = window.YippieDesign_488656;
const {
  Icon,
  PageHeader
} = window;
const TICKETS = [{
  id: 't1',
  subject: 'Invoice INV-0421 — corrected invoice requested',
  dept: 'Billing',
  status: 'open',
  stone: 'info',
  priority: 'high',
  ptone: 'high',
  last: 'Sent the corrected invoice, waiting on confirmation.',
  ago: '8m ago',
  date: '20 Jun 2026'
}, {
  id: 't2',
  subject: 'Account locked after failed logins',
  dept: 'Support',
  status: 'in_progress',
  stone: 'high',
  priority: 'urgent',
  ptone: 'urgent',
  last: 'Reset 2FA, asked customer to try again.',
  ago: '22m ago',
  date: '20 Jun 2026'
}, {
  id: 't3',
  subject: 'Upgrade Starter → Growth (annual)',
  dept: 'Sales',
  status: 'waiting',
  stone: 'waiting',
  priority: 'low',
  ptone: 'neutral',
  last: 'Sent annual quote with −20% applied.',
  ago: '1h ago',
  date: '20 Jun 2026'
}, {
  id: 't4',
  subject: 'WhatsApp widget not loading on mobile',
  dept: 'Support',
  status: 'resolved',
  stone: 'success',
  priority: 'medium',
  ptone: 'info',
  last: 'Cleared CDN cache — confirmed working.',
  ago: '3h ago',
  date: '19 Jun 2026'
}];
const STATUS_LABEL = {
  open: 'open',
  in_progress: 'in progress',
  waiting: 'waiting',
  resolved: 'resolved',
  closed: 'closed'
};
function TicketList() {
  const [filter, setFilter] = React.useState('All statuses');
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Tickets",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "plus",
        size: 16
      })
    }, "New ticket")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 240,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Select, {
    value: filter,
    onChange: e => setFilter(e.target.value),
    options: ['All statuses', 'Open', 'In progress', 'Waiting', 'Resolved', 'Closed']
  })), TICKETS.map(t => /*#__PURE__*/React.createElement(Card, {
    key: t.id,
    pad: 0,
    hoverable: true,
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 15,
      color: 'var(--text-heading)'
    }
  }, t.subject), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, t.dept)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '6px 0 0',
      fontSize: 12,
      color: 'var(--text-muted)',
      fontStyle: 'italic',
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "message-square",
    size: 12
  }), " ", t.last, " ", /*#__PURE__*/React.createElement("span", null, "\xB7 ", t.ago))), /*#__PURE__*/React.createElement(Badge, {
    tone: t.stone
  }, STATUS_LABEL[t.status])), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      marginTop: 10,
      fontSize: 13,
      color: 'var(--text-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: `var(--status-${t.ptone === 'neutral' ? 'waiting' : t.ptone})`,
      fontWeight: 600,
      textTransform: 'capitalize'
    }
  }, t.priority), /*#__PURE__*/React.createElement("span", null, t.date))))));
}
const CONTACTS = [{
  name: 'Lotte de Vries',
  email: 'finance@acmebv.com',
  company: 'Acme BV',
  phone: '+31 20 555 0142'
}, {
  name: 'Marco Jansen',
  email: 'ops@techcorp.io',
  company: 'TechCorp',
  phone: '+31 6 1234 5678'
}, {
  name: 'Sara Nordström',
  email: 'sara@nordex.io',
  company: 'Nordex',
  phone: '—'
}, {
  name: 'Bloom Agency',
  email: 'hello@bloom.agency',
  company: 'Bloom Agency',
  phone: '+44 20 7946 0991'
}, {
  name: 'Ridley Co',
  email: 'support@ridley.co',
  company: 'Ridley Co',
  phone: '+1 415 555 0117'
}];
function ContactList() {
  const [q, setQ] = React.useState('');
  const rows = CONTACTS.filter(c => (c.name + c.email + c.company).toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Contacts",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "plus",
        size: 16
      })
    }, "New contact")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 400,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Search by name, email, or company\u2026",
    value: q,
    onChange: e => setQ(e.target.value),
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "search",
      size: 16
    })
  })), /*#__PURE__*/React.createElement(Card, {
    pad: 0
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      borderBottom: '1px solid var(--border-default)',
      textAlign: 'left'
    }
  }, ['Name', 'Email', 'Company', 'Phone'].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      padding: '12px 16px',
      fontWeight: 600,
      color: 'var(--slate-600)',
      fontSize: 13
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, rows.map(c => /*#__PURE__*/React.createElement("tr", {
    key: c.email,
    style: {
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '12px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: c.name,
    size: 28
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'var(--brand)',
      fontWeight: 500
    }
  }, c.name))), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '12px 16px',
      color: 'var(--text-subtle)'
    }
  }, c.email), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '12px 16px',
      color: 'var(--text-subtle)'
    }
  }, c.company), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '12px 16px',
      color: 'var(--text-subtle)'
    }
  }, c.phone)))))), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 12,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, rows.length, " of ", CONTACTS.length, " contacts"));
}
Object.assign(window, {
  TicketList,
  ContactList
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Records.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Shell.jsx
try { (() => {
const {
  Button,
  Input
} = window.YippieDesign_488656;
const {
  Icon
} = window;
const NAV = [{
  id: 'inbox',
  label: 'Inbox',
  icon: 'inbox',
  badge: 3
}, {
  id: 'contacts',
  label: 'Contacts',
  icon: 'users'
}, {
  id: 'tickets',
  label: 'Tickets',
  icon: 'ticket'
}, {
  id: 'activity',
  label: 'Activity',
  icon: 'activity'
}, {
  id: 'billing',
  label: 'Billing',
  icon: 'credit-card'
}, {
  id: 'chat',
  label: 'Live Chat',
  icon: 'message-square'
}];
function Sidebar({
  view,
  setView
}) {
  const baseView = view === 'draft' ? 'inbox' : view;
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 'var(--sidebar-width)',
      minHeight: '100vh',
      background: 'var(--slate-800)',
      display: 'flex',
      flexDirection: 'column',
      padding: '24px 0',
      flexShrink: 0,
      position: 'sticky',
      top: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 20px 24px'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.svg",
    alt: "Yippie",
    style: {
      height: 34,
      display: 'block',
      marginBottom: 10
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 13,
      color: 'var(--slate-400)'
    }
  }, "Acme BV")), /*#__PURE__*/React.createElement("nav", {
    style: {
      flex: 1
    }
  }, NAV.map(n => {
    const active = baseView === n.id;
    return /*#__PURE__*/React.createElement("button", {
      key: n.id,
      onClick: () => setView(n.id),
      style: {
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '10px 20px',
        border: 'none',
        cursor: 'pointer',
        textAlign: 'left',
        fontFamily: 'var(--font-sans)',
        fontSize: 14,
        fontWeight: 500,
        color: active ? 'var(--white)' : 'var(--slate-400)',
        background: active ? 'var(--slate-700)' : 'transparent',
        borderLeft: active ? '3px solid var(--logo-cyan)' : '3px solid transparent'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 18
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, n.label), n.badge ? /*#__PURE__*/React.createElement("span", {
      style: {
        background: 'var(--red-500)',
        color: 'var(--white)',
        borderRadius: 999,
        fontSize: 10,
        fontWeight: 700,
        minWidth: 16,
        height: 16,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 4px'
      }
    }, n.badge) : null);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--slate-700)',
      paddingTop: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setView('settings'),
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 20px',
      border: 'none',
      cursor: 'pointer',
      textAlign: 'left',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      fontWeight: 500,
      color: 'var(--slate-400)',
      background: 'transparent',
      borderLeft: '3px solid transparent'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "settings",
    size: 18
  }), /*#__PURE__*/React.createElement("span", null, "Settings")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 20px 0'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: 'var(--slate-500)',
      margin: '4px 0 6px',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, "diederik@getyippie.com"))));
}
function LoginScreen({
  onLogin
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 380,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-2xl)',
      boxShadow: 'var(--shadow-lg)',
      border: '1px solid var(--border-default)',
      padding: 36
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.svg",
    alt: "Yippie",
    style: {
      height: 36,
      marginBottom: 24
    }
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '0 0 4px',
      fontSize: 22,
      fontWeight: 700,
      color: 'var(--text-heading)'
    }
  }, "Sign in"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 24px',
      fontSize: 14,
      color: 'var(--text-subtle)'
    }
  }, "Welcome back. Log in to your workspace."), /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      onLogin();
    },
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    type: "email",
    defaultValue: "diederik@getyippie.com",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "mail",
      size: 16
    })
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Password",
    type: "password",
    defaultValue: "password",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "lock",
      size: 16
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    variant: "primary",
    fullWidth: true
  }, "Sign in")))));
}
function PageHeader({
  title,
  subtitle,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      marginBottom: subtitle ? 16 : 24,
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 'var(--text-title)',
      fontWeight: 700,
      color: 'var(--text-heading)'
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '6px 0 0',
      fontSize: 14,
      color: 'var(--text-subtle)'
    }
  }, subtitle) : null), action);
}
function Placeholder({
  title,
  icon
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PageHeader, {
    title: title
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '80px 0',
      color: 'var(--text-muted)',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 40,
    stroke: 1.25
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14
    }
  }, "The ", title, " module lives here.")));
}
Object.assign(window, {
  Sidebar,
  LoginScreen,
  PageHeader,
  Placeholder
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/icons.jsx
try { (() => {
/* Icon — renders a lucide glyph as a real SVG (no DOM mutation).
   lucide UMD keys icons in PascalCase; each entry is a full svg node
   ["svg", attrs, [ [tag, attrs], ... ]]. We pull the child tuples. */
function Icon({
  name,
  size = 20,
  stroke = 1.75,
  color = 'currentColor',
  style = {}
}) {
  const lib = window.lucide || {};
  const pascal = String(name).replace(/(^|-)([a-z])/g, (_, __, c) => c.toUpperCase());
  const node = lib.icons && lib.icons[pascal] || lib[pascal];
  if (!node) return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      width: size,
      height: size
    }
  });
  const children = Array.isArray(node) && node[0] === 'svg' ? node[2] : node && node.iconNode ? node.iconNode : node;
  const parts = Array.isArray(children) ? children : [];
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flexShrink: 0,
      ...style
    }
  }, parts.map(([tag, attrs], i) => React.createElement(tag, {
    key: i,
    ...attrs
  })));
}
window.Icon = Icon;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/icons.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/Content.jsx
try { (() => {
const {
  Card,
  Eyebrow,
  Stat,
  Avatar,
  Badge
} = window.YippieDesign_488656;
const {
  Icon
} = window;
const FEATURES = [{
  icon: 'inbox',
  title: 'Smart Inbox',
  desc: 'Auto-drafts every support ticket from email & WhatsApp so you spend seconds instead of minutes on every message.'
}, {
  icon: 'ticket',
  title: 'Ticket Management',
  desc: 'Track, assign, and close requests in one place. SLA alerts fire before anything slips through.'
}, {
  icon: 'message-square',
  title: 'Live Chat',
  desc: 'Embed a chat widget with one line of code. Every conversation lands in a single dashboard.'
}, {
  icon: 'users',
  title: 'Contact Management',
  desc: 'Full customer history — emails, tickets, invoices — visible at a glance. No inbox digging.'
}, {
  icon: 'activity',
  title: 'Activity Feed',
  desc: 'Real-time log of everything in your business. Always know who did what and when.'
}, {
  icon: 'credit-card',
  title: 'Billing',
  desc: 'Send and track invoices without leaving the platform. Support and financials, in sync.'
}];
const STEPS = [{
  n: '01',
  title: 'Customer sends a message',
  desc: 'An email or WhatsApp message lands in your Yippie inbox automatically.'
}, {
  n: '02',
  title: 'AI drafts the ticket',
  desc: 'Yippie reads the message and suggests subject, priority, and description.'
}, {
  n: '03',
  title: 'You approve in one click',
  desc: 'Edit if you want, approve — it becomes a real ticket instantly.'
}];
const LOGOS = ['Acme BV', 'TechCorp', 'Nordex', 'Bloom Agency', 'Ridley Co'];
const INBOX = [{
  sender: 'Acme BV',
  subject: 'Invoice INV-0421 question',
  priority: 'High',
  tone: 'high',
  status: 'Open',
  stone: 'info'
}, {
  sender: 'TechCorp',
  subject: 'Login issue — account locked',
  priority: 'Urgent',
  tone: 'urgent',
  status: 'In progress',
  stone: 'high'
}, {
  sender: 'Nordex',
  subject: 'Pricing plan upgrade',
  priority: 'Low',
  tone: 'neutral',
  status: 'Resolved',
  stone: 'success'
}, {
  sender: 'Bloom Agency',
  subject: 'Onboarding call request',
  priority: 'Normal',
  tone: 'neutral',
  status: 'Open',
  stone: 'info'
}, {
  sender: 'Ridley Co',
  subject: 'API key rotation needed',
  priority: 'High',
  tone: 'high',
  status: 'In progress',
  stone: 'high'
}];
const Wrap = ({
  children,
  bg,
  narrow
}) => /*#__PURE__*/React.createElement("section", {
  style: {
    background: bg,
    padding: '112px 32px'
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    maxWidth: narrow ? 'var(--container-narrow)' : 'var(--container-max)',
    margin: '0 auto'
  }
}, children));
function LogoBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-page)',
      borderTop: '1px solid var(--border-subtle)',
      borderBottom: '1px solid var(--border-subtle)',
      padding: '32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "muted",
    style: {
      marginBottom: 20
    }
  }, "Teams at these businesses use Yippie"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
      gap: '8px 40px'
    }
  }, LOGOS.map(n => /*#__PURE__*/React.createElement("span", {
    key: n,
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: 'var(--text-muted)'
    }
  }, n)))));
}
function Stats() {
  const data = [{
    value: '10h+',
    label: 'saved per week per person'
  }, {
    value: '<2 min',
    label: 'average ticket response time'
  }, {
    value: '6',
    label: 'modules, one platform'
  }];
  return /*#__PURE__*/React.createElement(Wrap, {
    bg: "var(--surface-card)",
    narrow: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 48
    }
  }, data.map(s => /*#__PURE__*/React.createElement(Stat, {
    key: s.label,
    value: s.value,
    label: s.label
  }))));
}
function SectionHead({
  eyebrow,
  title,
  sub,
  dark
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 64
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 12
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 16px',
      fontSize: 'var(--text-h1)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-tight)',
      color: dark ? 'var(--white)' : 'var(--text-heading)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 auto',
      maxWidth: 560,
      fontSize: 18,
      lineHeight: 'var(--leading-relaxed)',
      color: dark ? 'var(--slate-400)' : 'var(--text-body)'
    }
  }, sub));
}
function Features() {
  return /*#__PURE__*/React.createElement(Wrap, {
    bg: "var(--surface-page)"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "Features",
    title: "Everything your support team needs",
    sub: "One platform for inbox, tickets, live chat, contacts, billing, and activity. Stop juggling tools."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '40px 48px',
      maxWidth: 'var(--container-narrow)',
      margin: '0 auto'
    }
  }, FEATURES.map(f => /*#__PURE__*/React.createElement("div", {
    key: f.title,
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      width: 40,
      height: 40,
      borderRadius: 12,
      background: 'var(--slate-100)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--brand)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: f.icon,
    size: 20
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 4px',
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--text-heading)'
    }
  }, f.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-body)'
    }
  }, f.desc))))));
}
function HowItWorks() {
  return /*#__PURE__*/React.createElement(Wrap, {
    bg: "var(--surface-card)"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "How it works",
    title: "From email to resolved \u2014 in seconds",
    sub: "Yippie's AI reads every incoming message and does the write-up for you."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24,
      maxWidth: 'var(--container-narrow)',
      margin: '0 auto'
    }
  }, STEPS.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.n
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 60,
      fontWeight: 700,
      lineHeight: 1,
      marginBottom: 16,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--yippie-200)'
    }
  }, s.n), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--text-heading)'
    }
  }, s.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-body)'
    }
  }, s.desc)))));
}
function ProductMoment() {
  return /*#__PURE__*/React.createElement(Wrap, {
    bg: "var(--slate-900)"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    dark: true,
    eyebrow: "",
    title: "Everything in one place",
    sub: "Your entire support operation \u2014 inbox, tickets, contacts, billing \u2014 unified in a single dashboard."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-narrow)',
      margin: '0 auto',
      borderRadius: 'var(--radius-2xl)',
      overflow: 'hidden',
      border: '1px solid rgba(51,65,85,0.5)',
      boxShadow: 'var(--shadow-2xl)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--slate-800)',
      borderBottom: '1px solid var(--slate-700)',
      padding: '10px 16px',
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, [0, 1, 2].map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: 'var(--slate-600)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      margin: '0 16px',
      background: 'var(--slate-700)',
      borderRadius: 4,
      fontSize: 10,
      color: 'var(--slate-500)',
      padding: '2px 8px',
      textAlign: 'center'
    }
  }, "app.getyippie.com/inbox")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      background: 'var(--slate-900)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--brand)',
      width: 56,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      paddingTop: 20,
      gap: 12
    }
  }, [true, false, false, false, false, false].map((a, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      width: 32,
      height: 32,
      borderRadius: 10,
      background: a ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.1)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 20px',
      borderBottom: '1px solid var(--slate-800)',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--slate-400)'
    }
  }, "Inbox"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--slate-500)'
    }
  }, INBOX.length, " messages")), INBOX.map(r => /*#__PURE__*/React.createElement("div", {
    key: r.sender,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: '14px 20px',
      borderBottom: '1px solid rgba(30,41,59,0.6)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: r.sender,
    tone: "dark",
    size: 28
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--slate-200)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, r.sender), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--slate-500)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, r.subject)), /*#__PURE__*/React.createElement(Badge, {
    tone: r.tone
  }, r.priority), /*#__PURE__*/React.createElement(Badge, {
    tone: r.stone
  }, r.status)))))));
}
function CTA() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--brand)',
      padding: '96px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '0 auto',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 16px',
      fontSize: 'var(--text-h1)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--white)'
    }
  }, "Ready to win back your time?"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 32px',
      fontSize: 18,
      lineHeight: 'var(--leading-relaxed)',
      color: 'rgba(255,255,255,0.75)'
    }
  }, "Join businesses that handle customer support in half the time. Start for free, no credit card required."), /*#__PURE__*/React.createElement("button", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      padding: '14px 32px',
      borderRadius: 'var(--radius-xl)',
      background: 'var(--white)',
      color: 'var(--brand)',
      fontWeight: 600,
      fontSize: 16,
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--font-sans)'
    }
  }, "Start for free ", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 18
  }))));
}
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--surface-card)',
      borderTop: '1px solid var(--border-subtle)',
      padding: '32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.svg",
    alt: "Yippie",
    style: {
      height: 28
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 24,
      flexWrap: 'wrap'
    }
  }, ['Features', 'Pricing', 'Log in'].map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, l)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--slate-300)'
    }
  }, "\xA9 2026 Yippie"))));
}
Object.assign(window, {
  LogoBar,
  Stats,
  Features,
  HowItWorks,
  ProductMoment,
  CTA,
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/Content.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/Hero.jsx
try { (() => {
const {
  Button,
  Badge
} = window.YippieDesign_488656;
const {
  Icon
} = window;
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-card)',
      padding: '120px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 64,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 24,
      padding: '5px 12px',
      borderRadius: 'var(--radius-full)',
      border: '1px solid rgba(91,164,245,0.3)',
      background: 'var(--brand-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--brand)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: '0.02em',
      color: 'var(--brand)'
    }
  }, "AI customer service")), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '0 0 24px',
      fontSize: 'var(--text-display)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-tight)',
      lineHeight: 1.05,
      color: 'var(--text-heading)'
    }
  }, "Give yourself back the time that matters"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 32px',
      maxWidth: 380,
      fontSize: 18,
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-body)'
    }
  }, "Yippie auto-drafts every support ticket from your inbox. Review, approve, done."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 18
    })
  }, "Start for free"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg"
  }, "See how it works"))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%,-50%)',
      width: 288,
      height: 288,
      borderRadius: '50%',
      filter: 'blur(64px)',
      background: 'var(--brand)',
      opacity: 0.12,
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      maxWidth: 384,
      transform: 'rotate(1deg)',
      borderRadius: 'var(--radius-2xl)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-2xl)',
      border: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--slate-100)',
      borderBottom: '1px solid var(--border-default)',
      padding: '10px 16px',
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, [0, 1, 2].map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: 'var(--slate-300)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      margin: '0 16px',
      background: 'var(--surface-card)',
      borderRadius: 4,
      fontSize: 10,
      color: 'var(--text-muted)',
      padding: '2px 8px',
      textAlign: 'center'
    }
  }, "app.getyippie.com")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: 288,
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--brand)',
      width: 48,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      paddingTop: 16,
      gap: 8
    }
  }, [true, false, false, false, false].map((a, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      width: 28,
      height: 28,
      borderRadius: 8,
      background: a ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.1)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 8,
      padding: 12,
      background: 'var(--surface-page)'
    }
  }, ['Customer', 'Email', 'Ticket', 'Reply'].map(label => /*#__PURE__*/React.createElement("div", {
    key: label,
    style: {
      background: 'var(--surface-card)',
      borderRadius: 12,
      border: '1px solid var(--border-subtle)',
      boxShadow: 'var(--shadow-xs)',
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      fontWeight: 600,
      color: 'var(--text-muted)',
      marginBottom: 8,
      textTransform: 'uppercase',
      letterSpacing: '0.1em'
    }
  }, label), [0.75, 0.5, 0.66].map((w, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      height: 6,
      background: 'var(--slate-100)',
      borderRadius: 999,
      width: `${w * 100}%`,
      marginBottom: 6
    }
  }))))))))));
}
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/Nav.jsx
try { (() => {
const {
  Button,
  Input
} = window.YippieDesign_488656;
const {
  Icon
} = window;
function Nav({
  onSignUp
}) {
  const links = ['Features', 'How it works', 'Pricing'];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 50,
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 32px',
      height: 64,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.svg",
    alt: "Yippie",
    style: {
      height: 32
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, "Customer support, made easy")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 28
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      fontSize: 14,
      color: 'var(--text-body)'
    }
  }, l)), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: onSignUp
  }, "Sign up"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 14
    })
  }, "Log in"))));
}
function SignUpModal({
  onClose
}) {
  const [status, setStatus] = React.useState('idle');
  const fields = [{
    key: 'name',
    label: 'Full name',
    type: 'text',
    required: true
  }, {
    key: 'email',
    label: 'Work email',
    type: 'email',
    required: true
  }, {
    key: 'company',
    label: 'Company',
    type: 'text',
    required: false
  }, {
    key: 'phone',
    label: 'Phone number',
    type: 'tel',
    required: false
  }];
  return /*#__PURE__*/React.createElement("div", {
    onClick: e => {
      if (e.target === e.currentTarget) onClose();
    },
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 100,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 16,
      background: 'rgba(15,24,36,0.55)',
      backdropFilter: 'blur(4px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      maxWidth: 420,
      padding: 32,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-2xl)',
      boxShadow: 'var(--shadow-2xl)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Close",
    style: {
      position: 'absolute',
      top: 16,
      right: 16,
      border: 'none',
      background: 'transparent',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 20
  })), status === 'success' ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '12px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 48,
      height: 48,
      borderRadius: '50%',
      background: 'var(--brand-subtle)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      margin: '0 auto 16px',
      color: 'var(--brand)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 24,
    stroke: 2.5
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontSize: 18,
      fontWeight: 700,
      color: 'var(--text-heading)'
    }
  }, "You're on the list"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      color: 'var(--text-subtle)'
    }
  }, "We'll be in touch shortly."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: onClose
  }, "Close"))) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 4px',
      fontSize: 20,
      fontWeight: 700,
      color: 'var(--text-heading)'
    }
  }, "Get started with Yippie"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 24px',
      fontSize: 14,
      color: 'var(--text-subtle)'
    }
  }, "We'll reach out to set up your account."), /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setStatus('success');
    },
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, fields.map(f => /*#__PURE__*/React.createElement(Input, {
    key: f.key,
    label: f.label,
    type: f.type,
    required: f.required
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    variant: "primary",
    fullWidth: true,
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 16
    })
  }, "Request access"))))));
}
Object.assign(window, {
  Nav,
  SignUpModal
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/Nav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/Pricing.jsx
try { (() => {
const {
  Card,
  Eyebrow,
  Toggle,
  Button
} = window.YippieDesign_488656;
const {
  Icon
} = window;
const PLANS = [{
  tier: 'Starter',
  desc: 'For solo founders getting started',
  m: '€29',
  a: '€23',
  features: ['1 user', '500 contacts', 'Inbox + Tickets', 'Live chat widget', 'Email support'],
  cta: 'Get started',
  featured: false
}, {
  tier: 'Growth',
  desc: 'For teams handling more volume',
  m: '€79',
  a: '€63',
  features: ['5 users', '5,000 contacts', 'All modules', 'Activity feed', 'Priority support'],
  cta: 'Get started',
  featured: true
}, {
  tier: 'Pro',
  desc: 'For businesses at scale',
  m: '€199',
  a: '€159',
  features: ['Unlimited users', 'Unlimited contacts', 'All modules', 'API access', 'Dedicated support'],
  cta: 'Contact us',
  featured: false
}];
function Pricing() {
  const [annual, setAnnual] = React.useState(false);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-card)',
      padding: '112px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 12
    }
  }, "Pricing"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 16px',
      fontSize: 'var(--text-h1)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-heading)'
    }
  }, "Simple, honest pricing"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 auto',
      maxWidth: 560,
      fontSize: 18,
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-body)'
    }
  }, "No hidden fees. Cancel anytime. Start free and upgrade when you grow.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 12,
      marginBottom: 56
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: annual ? 'var(--text-muted)' : 'var(--text-heading)'
    }
  }, "Monthly"), /*#__PURE__*/React.createElement(Toggle, {
    checked: annual,
    onChange: setAnnual
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: annual ? 'var(--text-heading)' : 'var(--text-muted)'
    }
  }, "Annual ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--brand)',
      fontWeight: 600
    }
  }, "\u221220%"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24,
      maxWidth: 'var(--container-narrow)',
      margin: '0 auto',
      alignItems: 'start'
    }
  }, PLANS.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.tier,
    radius: "2xl",
    pad: 32,
    featured: p.featured,
    style: {
      position: 'relative'
    }
  }, p.featured && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: -12,
      left: '50%',
      transform: 'translateX(-50%)',
      background: 'var(--brand)',
      color: 'var(--white)',
      fontSize: 12,
      fontWeight: 600,
      padding: '2px 12px',
      borderRadius: 'var(--radius-full)',
      whiteSpace: 'nowrap'
    }
  }, "Most popular"), /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "muted",
    style: {
      marginBottom: 12
    }
  }, p.tier), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 4,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 48,
      fontWeight: 700,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-heading)'
    }
  }, annual ? p.a : p.m), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)',
      marginBottom: 8
    }
  }, "/mo")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 24px',
      paddingBottom: 24,
      borderBottom: '1px solid var(--border-subtle)',
      fontSize: 14,
      color: 'var(--text-subtle)',
      lineHeight: 'var(--leading-relaxed)'
    }
  }, p.desc), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      padding: 0,
      margin: '0 0 32px',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, p.features.map(f => /*#__PURE__*/React.createElement("li", {
    key: f,
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 8,
      fontSize: 14,
      color: 'var(--slate-700)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--brand)',
      display: 'flex',
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 16,
    stroke: 2.5
  })), f))), /*#__PURE__*/React.createElement(Button, {
    variant: p.featured ? 'primary' : 'secondary',
    fullWidth: true
  }, p.cta))))));
}
window.Pricing = Pricing;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/Pricing.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/icons.jsx
try { (() => {
/* Icon — renders a lucide glyph as a real SVG (no DOM mutation).
   lucide UMD keys icons in PascalCase; each entry is a full svg node
   ["svg", attrs, [ [tag, attrs], ... ]]. We pull the child tuples. */
function Icon({
  name,
  size = 20,
  stroke = 1.75,
  color = 'currentColor',
  style = {}
}) {
  const lib = window.lucide || {};
  const pascal = String(name).replace(/(^|-)([a-z])/g, (_, __, c) => c.toUpperCase());
  const node = lib.icons && lib.icons[pascal] || lib[pascal];
  if (!node) return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      width: size,
      height: size
    }
  });
  const children = Array.isArray(node) && node[0] === 'svg' ? node[2] : node && node.iconNode ? node.iconNode : node;
  const parts = Array.isArray(children) ? children : [];
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flexShrink: 0,
      ...style
    }
  }, parts.map(([tag, attrs], i) => React.createElement(tag, {
    key: i,
    ...attrs
  })));
}
window.Icon = Icon;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/icons.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Toggle = __ds_scope.Toggle;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
