const { Icon } = window;

/* ── useSelection — shared list-selection state ─────────────────────── */
function useSelection(ids) {
  const [sel, setSel] = React.useState(() => new Set());
  // keep selection valid if the underlying list changes (filter/search)
  React.useEffect(() => {
    setSel(prev => {
      const next = new Set([...prev].filter(id => ids.includes(id)));
      return next.size === prev.size ? prev : next;
    });
  }, [ids.join('|')]);
  const toggle = (id, e) => { if (e) e.stopPropagation(); setSel(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; }); };
  const toggleAll = () => setSel(prev => (prev.size === ids.length && ids.length > 0) ? new Set() : new Set(ids));
  const clear = () => setSel(new Set());
  return {
    sel, toggle, toggleAll, clear,
    has: id => sel.has(id),
    count: sel.size,
    all: ids.length > 0 && sel.size === ids.length,
    some: sel.size > 0 && sel.size < ids.length,
  };
}

/* ── Checkbox — branded, supports indeterminate.
   Rendered as an inline SVG (fill, not background) so nothing in the cascade
   can flatten its checked state. Keyboard-operable via role + tabIndex. ──── */
function Checkbox({ checked, indeterminate, onChange, size = 18, ariaLabel }) {
  const on = checked || indeterminate;
  const key = (e) => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); onChange(e); } };
  const fill = on ? '#5ba4f5' : '#ffffff';
  const stroke = on ? '#5ba4f5' : '#cbd5e1';
  return (
    <span role="checkbox" tabIndex={0} aria-checked={indeterminate ? 'mixed' : !!checked} aria-label={ariaLabel}
      onClick={(e) => onChange(e)} onKeyDown={key}
      style={{ display: 'inline-flex', flexShrink: 0, cursor: 'pointer', lineHeight: 0, borderRadius: 5 }}>
      <svg width={size} height={size} viewBox="0 0 18 18" aria-hidden="true">
        <rect x="0.9" y="0.9" width="16.2" height="16.2" rx="4.2" fill={fill} stroke={stroke} strokeWidth="1.5" />
        {indeterminate
          ? <rect x="4.5" y="8" width="9" height="2" rx="1" fill="#ffffff" />
          : checked
            ? <path d="M4.8 9.3 L7.6 12 L13.2 6.2" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            : null}
      </svg>
    </span>
  );
}

/* ── BulkBar — appears above a list when ≥1 row is selected ─────────── */
function BulkBar({ count, onClear, actions = [] }) {
  if (!count) return null;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16,
      padding: '10px 12px 10px 18px', borderRadius: 'var(--radius-md)',
      background: 'var(--ink)', color: '#fff', boxShadow: 'var(--shadow-md)',
    }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12.5, fontWeight: 600 }}>{count} selected</span>
      <span style={{ width: 1, height: 18, background: 'rgba(255,255,255,0.2)' }} />
      <div style={{ display: 'flex', gap: 6, flex: 1, flexWrap: 'wrap' }}>
        {actions.map(a => (
          <button key={a.label} onClick={a.onClick} style={{
            display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 12px', borderRadius: 'var(--radius-sm)',
            border: '1px solid rgba(255,255,255,0.18)', background: a.danger ? 'rgba(239,68,68,0.9)' : 'rgba(255,255,255,0.08)',
            color: '#fff', fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 600, cursor: 'pointer',
          }}>
            {a.icon ? <Icon name={a.icon} size={14} color="currentColor" /> : null}{a.label}
          </button>
        ))}
      </div>
      <button onClick={onClear} aria-label="Clear selection" style={{
        display: 'inline-flex', alignItems: 'center', gap: 6, border: 'none', background: 'transparent',
        color: 'rgba(255,255,255,0.7)', fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 600, cursor: 'pointer', padding: '6px 8px',
      }}>
        <Icon name="x" size={14} color="currentColor" /> Clear
      </button>
    </div>
  );
}

Object.assign(window, { useSelection, Checkbox, BulkBar });
