const { Icon } = window;

/* ── useContextMenu — open a themed menu at the cursor ──────────────────
   const ctx = useContextMenu();
   <div onContextMenu={(e) => ctx.open(e, [ {label,icon,onClick,danger}, {separator:true}, {header:'…'} ])}>
   <ContextMenu state={ctx.state} onClose={ctx.close} />
   ─────────────────────────────────────────────────────────────────────── */
function useContextMenu() {
  const [state, setState] = React.useState(null); // { x, y, items }
  const open = (e, items) => { e.preventDefault(); e.stopPropagation(); setState({ x: e.clientX, y: e.clientY, items }); };
  const close = () => setState(null);
  return { state, open, close };
}

function ContextMenu({ state, onClose }) {
  const ref = React.useRef(null);
  const [pos, setPos] = React.useState({ x: 0, y: 0, ready: false });
  const [hover, setHover] = React.useState(-1);

  React.useEffect(() => {
    if (!state) { setPos(p => ({ ...p, ready: false })); return; }
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    const onScroll = () => onClose();
    window.addEventListener('keydown', onKey);
    window.addEventListener('scroll', onScroll, true);
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('scroll', onScroll, true);
      window.removeEventListener('resize', onScroll);
    };
  }, [state]);

  // clamp to viewport once measured
  React.useLayoutEffect(() => {
    if (!state || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const pad = 8;
    const x = Math.min(state.x, window.innerWidth - r.width - pad);
    const y = Math.min(state.y, window.innerHeight - r.height - pad);
    setPos({ x: Math.max(pad, x), y: Math.max(pad, y), ready: true });
  }, [state]);

  if (!state) return null;

  return (
    <div onClick={onClose} onContextMenu={(e) => { e.preventDefault(); onClose(); }}
      style={{ position: 'fixed', inset: 0, zIndex: 300 }}>
      <div ref={ref} role="menu" onClick={(e) => e.stopPropagation()}
        style={{
          position: 'fixed', left: pos.x, top: pos.y, minWidth: 208, padding: 6,
          background: '#fff', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-md)',
          boxShadow: 'var(--shadow-lg)', fontFamily: 'var(--font-body)',
          opacity: pos.ready ? 1 : 0, transform: pos.ready ? 'scale(1)' : 'scale(0.97)',
          transformOrigin: 'top left', transition: 'opacity 90ms ease, transform 90ms ease',
        }}>
        {state.items.map((it, i) => {
          if (it.separator) return <div key={i} style={{ height: 1, background: 'var(--border-subtle)', margin: '6px 4px' }} />;
          if (it.header) return (
            <div key={i} style={{ padding: '7px 10px 4px', fontFamily: 'var(--font-mono)', fontSize: 10.5, fontWeight: 600,
              letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>{it.header}</div>
          );
          const danger = !!it.danger;
          const isHover = hover === i;
          return (
            <button key={i} role="menuitem" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(-1)}
              onClick={() => { onClose(); it.onClick && it.onClick(); }}
              style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px',
                border: 'none', borderRadius: 'var(--radius-sm)', cursor: 'pointer', textAlign: 'left',
                fontFamily: 'var(--font-body)', fontSize: 13.5, fontWeight: 500, lineHeight: 1,
                color: danger ? 'var(--status-urgent)' : 'var(--text-body)',
                background: isHover ? (danger ? 'var(--status-urgent-bg)' : 'var(--brand-soft)') : 'transparent',
                transition: 'background 100ms ease',
              }}>
              {it.icon ? <span style={{ display: 'inline-flex', color: danger ? 'var(--status-urgent)' : (isHover ? 'var(--brand-deep)' : 'var(--text-subtle)') }}><Icon name={it.icon} size={15} color="currentColor" /></span> : <span style={{ width: 15 }} />}
              <span style={{ flex: 1 }}>{it.label}</span>
              {it.shortcut ? <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-muted)' }}>{it.shortcut}</span> : null}
            </button>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { useContextMenu, ContextMenu });
