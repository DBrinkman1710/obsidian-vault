const { Badge, Button, Card, Avatar } = window.YippieDesign_488656;
const { Icon, PageHeader, useSelection, Checkbox, BulkBar, useContextMenu, ContextMenu } = window;

/* ── Calendar & Bookings ─────────────────────────────────────── */
const BOOKINGS = [
  { day: 3, time: '09:30', title: 'Onboarding — Bloom Agency', tone: 'info' },
  { day: 3, time: '14:00', title: 'Demo — Vela Foods', tone: 'success' },
  { day: 5, time: '11:00', title: 'Support call — TechCorp', tone: 'high' },
  { day: 11, time: '10:00', title: 'Quarterly review — Acme BV', tone: 'info' },
  { day: 12, time: '15:30', title: 'Discovery — Ridley Co', tone: 'waiting' },
  { day: 18, time: '13:00', title: 'Renewal — Nordex', tone: 'success' },
  { day: 24, time: '16:00', title: 'Demo — Lumen Studio', tone: 'info' },
];
const TONE_BG = { info: 'var(--status-info-bg)', success: 'var(--status-success-bg)', high: 'var(--status-high-bg)', waiting: 'var(--status-waiting-bg)' };
const TONE_FG = { info: 'var(--status-info)', success: 'var(--status-success)', high: 'var(--status-high)', waiting: 'var(--status-waiting)' };

function CalendarView() {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  // June 2026 starts on a Monday → simple 1-based grid.
  const cells = Array.from({ length: 35 }, (_, i) => i - 0 + 1).map(d => (d >= 1 && d <= 30 ? d : null));
  const today = 6;
  return (
    <div>
      <PageHeader title="Calendar" subtitle="Bookings and meetings across your team — synced to every contact."
        action={<Button variant="primary" icon={<Icon name="plus" size={16} />}>New booking</Button>} />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 20, alignItems: 'start' }}>
        <Card pad={0}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px', borderBottom: '1px solid var(--border-subtle)' }}>
            <h2 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 600, color: 'var(--ink)' }}>June 2026</h2>
            <div style={{ display: 'flex', gap: 6 }}>
              <button style={navBtn}><Icon name="chevron-left" size={16} /></button>
              <button style={navBtn}><Icon name="chevron-right" size={16} /></button>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)' }}>
            {days.map(d => (
              <div key={d} style={{ padding: '10px 12px', fontFamily: 'var(--font-mono)', fontSize: 11, textTransform: 'uppercase',
                letterSpacing: '0.04em', color: 'var(--text-muted)', borderBottom: '1px solid var(--border-subtle)' }}>{d}</div>
            ))}
            {cells.map((d, i) => {
              const evs = d ? BOOKINGS.filter(b => b.day === d) : [];
              return (
                <div key={i} style={{ minHeight: 92, padding: 8, borderRight: (i % 7 !== 6) ? '1px solid var(--border-subtle)' : 'none',
                  borderBottom: '1px solid var(--border-subtle)', background: d === today ? 'var(--brand-soft)' : 'transparent' }}>
                  {d ? <div style={{ fontSize: 12, fontWeight: d === today ? 700 : 500, color: d === today ? 'var(--brand-deep)' : 'var(--text-subtle)', marginBottom: 4 }}>{d}</div> : null}
                  {evs.map((e, j) => (
                    <div key={j} style={{ background: TONE_BG[e.tone], color: TONE_FG[e.tone], borderRadius: 6, padding: '3px 6px',
                      fontSize: 10.5, fontWeight: 600, marginBottom: 3, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {e.time} {e.title}
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        </Card>
        <Card pad={20}>
          <p style={{ margin: '0 0 14px', fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600, color: 'var(--brand-deep)' }}>// Upcoming</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {BOOKINGS.slice(0, 5).map((b, i) => (
              <div key={i} style={{ display: 'flex', gap: 12 }}>
                <div style={{ width: 4, borderRadius: 4, background: TONE_FG[b.tone], flexShrink: 0 }} />
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{b.title}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11.5, color: 'var(--text-muted)' }}>Jun {b.day} · {b.time}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
const navBtn = { width: 30, height: 30, borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-default)',
  background: '#fff', color: 'var(--text-subtle)', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' };

/* ── Live Chat ───────────────────────────────────────────────── */
const SESSIONS = [
  { id: 's1', name: 'Emma Larsson', company: 'Vela Foods', last: 'Perfect, that worked — thank you!', when: 'now', unread: 0, status: 'open', active: true },
  { id: 's2', name: 'James Okoro', company: 'Ridley Co', last: 'Is the widget available on mobile too?', when: '2m', unread: 2, status: 'open' },
  { id: 's3', name: 'Sofia Rossi', company: 'Lumen Studio', last: 'I’ll check with my team and get back', when: '18m', unread: 0, status: 'waiting' },
  { id: 's4', name: 'Daan Visser', company: 'Acme BV', last: 'Thanks for the quick response 🙏', when: '1h', unread: 0, status: 'resolved' },
];
const CONVO = [
  { from: 'them', text: 'Hi! We just embedded the chat widget but it isn’t showing on our mobile site.' },
  { from: 'me', text: 'Hi Emma! Happy to help. Which snippet did you paste — the one ending in /widget.js?' },
  { from: 'them', text: 'Yes, that one. It works fine on desktop though.' },
  { from: 'me', text: 'Got it. Add data-mobile="true" to the script tag — mobile is opt-in. That should do it.' },
  { from: 'them', text: 'Perfect, that worked — thank you!' },
];

function ChatView() {
  const [active, setActive] = React.useState('s1');
  const statusTone = { open: 'success', waiting: 'high', resolved: 'neutral' };
  const ids = SESSIONS.map(s => s.id);
  const sel = useSelection(ids);
  const ctx = useContextMenu();
  const menuFor = (s) => [
    { header: s.name },
    { label: 'Open conversation', icon: 'arrow-right', onClick: () => setActive(s.id) },
    { label: 'Assign to\u2026', icon: 'user-plus' },
    { label: 'Mark resolved', icon: 'check' },
    { label: 'Mark as read', icon: 'mail-open' },
    { separator: true },
    { label: 'Delete', icon: 'trash-2', danger: true },
  ];
  return (
    <div>
      <ContextMenu state={ctx.state} onClose={ctx.close} />
      <PageHeader title="Live Chat" subtitle="Every website conversation in one shared dashboard." />
      <BulkBar count={sel.count} onClear={sel.clear} actions={[
        { label: 'Assign', icon: 'user-plus', onClick: sel.clear },
        { label: 'Resolve', icon: 'check', onClick: sel.clear },
        { label: 'Mark read', icon: 'mail-open', onClick: sel.clear },
        { label: 'Delete', icon: 'trash-2', danger: true, onClick: sel.clear },
      ]} />
      <Card pad={0} style={{ overflow: 'hidden' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr', height: 540 }}>
          {/* session list */}
          <div style={{ borderRight: '1px solid var(--border-default)', overflowY: 'auto' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 16px', borderBottom: '1px solid var(--border-subtle)', background: 'var(--off-white)', position: 'sticky', top: 0, zIndex: 1 }}>
              <Checkbox checked={sel.all} indeterminate={sel.some} onChange={sel.toggleAll} ariaLabel="Select all conversations" />
              <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-subtle)' }}>{sel.count ? `${sel.count} selected` : 'Conversations'}</span>
            </div>
            {SESSIONS.map(s => {
              const on = s.id === active;
              const checked = sel.has(s.id);
              return (
                <div key={s.id} onClick={() => setActive(s.id)} onContextMenu={(e) => ctx.open(e, menuFor(s))} style={{ width: '100%', textAlign: 'left',
                  borderBottom: '1px solid var(--border-subtle)', cursor: 'pointer', padding: '14px 16px',
                  background: checked ? 'var(--brand-soft)' : on ? 'var(--brand-soft)' : 'transparent', display: 'flex', gap: 10, alignItems: 'flex-start', fontFamily: 'var(--font-body)' }}>
                  <div style={{ paddingTop: 9 }}><Checkbox checked={checked} onChange={(e) => sel.toggle(s.id, e)} ariaLabel={`Select chat with ${s.name}`} /></div>
                  <Avatar name={s.name} size={36} tone={on ? 'brand' : 'slate'} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                      <span style={{ fontSize: 13.5, fontWeight: 600, color: 'var(--ink)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.name}</span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-muted)', flexShrink: 0 }}>{s.when}</span>
                    </div>
                    <div style={{ fontSize: 12.5, color: 'var(--text-muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', margin: '2px 0 4px' }}>{s.last}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <Badge tone={statusTone[s.status]} dot>{s.status}</Badge>
                      {s.unread ? <span style={{ marginLeft: 'auto', background: 'var(--brand)', color: '#fff', fontSize: 10, fontWeight: 700,
                        minWidth: 18, height: 18, borderRadius: 999, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', padding: '0 5px' }}>{s.unread}</span> : null}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          {/* conversation */}
          <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 20px', borderBottom: '1px solid var(--border-subtle)' }}>
              <Avatar name="Emma Larsson" size={32} tone="brand" />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>Emma Larsson</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Vela Foods · vela.example.com</div>
              </div>
              <Badge tone="success" dot>open</Badge>
            </div>
            <div style={{ flex: 1, overflowY: 'auto', padding: 20, display: 'flex', flexDirection: 'column', gap: 10, background: 'var(--off-white)' }}>
              {CONVO.map((m, i) => (
                <div key={i} style={{ alignSelf: m.from === 'me' ? 'flex-end' : 'flex-start', maxWidth: '74%',
                  background: m.from === 'me' ? 'var(--brand)' : '#fff', color: m.from === 'me' ? '#fff' : 'var(--text-body)',
                  border: m.from === 'me' ? 'none' : '1px solid var(--border-default)',
                  borderRadius: m.from === 'me' ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
                  padding: '10px 14px', fontSize: 13.5, lineHeight: 1.5 }}>{m.text}</div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 10, padding: 16, borderTop: '1px solid var(--border-subtle)', alignItems: 'center' }}>
              <input placeholder="Type a reply…" style={{ flex: 1, padding: '11px 14px', borderRadius: 'var(--radius-sm)',
                border: '1px solid var(--border-default)', fontFamily: 'var(--font-body)', fontSize: 14, color: 'var(--text-heading)', outline: 'none' }} />
              <Button variant="primary" icon={<Icon name="send" size={15} />}>Send</Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

Object.assign(window, { CalendarView, ChatView });
