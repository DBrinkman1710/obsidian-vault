const { Badge, Button, Select, Input, Card, Avatar } = window.YippieDesign_488656;
const { Icon, PageHeader, useSelection, Checkbox, BulkBar, useContextMenu, ContextMenu } = window;

const TICKETS = [
  { id: 't1', subject: 'Invoice INV-0421 — corrected invoice requested', dept: 'Billing', status: 'open', stone: 'info',
    priority: 'high', ptone: 'high', last: 'Sent the corrected invoice, waiting on confirmation.', ago: '8m ago', date: '20 Jun 2026' },
  { id: 't2', subject: 'Account locked after failed logins', dept: 'Support', status: 'in_progress', stone: 'high',
    priority: 'urgent', ptone: 'urgent', last: 'Reset 2FA, asked customer to try again.', ago: '22m ago', date: '20 Jun 2026' },
  { id: 't3', subject: 'Upgrade Starter → Growth (annual)', dept: 'Sales', status: 'waiting', stone: 'waiting',
    priority: 'low', ptone: 'neutral', last: 'Sent annual quote with −20% applied.', ago: '1h ago', date: '20 Jun 2026' },
  { id: 't4', subject: 'WhatsApp widget not loading on mobile', dept: 'Support', status: 'resolved', stone: 'success',
    priority: 'medium', ptone: 'info', last: 'Cleared CDN cache — confirmed working.', ago: '3h ago', date: '19 Jun 2026' },
];

const STATUS_LABEL = { open: 'open', in_progress: 'in progress', waiting: 'waiting', resolved: 'resolved', closed: 'closed' };

function TicketList() {
  const [filter, setFilter] = React.useState('All statuses');
  const ids = TICKETS.map(t => t.id);
  const s = useSelection(ids);
  const ctx = useContextMenu();
  const menuFor = (t) => [
    { header: t.subject.length > 28 ? t.subject.slice(0, 28) + '\u2026' : t.subject },
    { label: 'Open ticket', icon: 'arrow-right' },
    { label: 'Assign to\u2026', icon: 'user-plus' },
    { label: 'Change priority', icon: 'flag' },
    { separator: true },
    { label: 'Mark resolved', icon: 'check' },
    { label: 'Close ticket', icon: 'archive' },
    { separator: true },
    { label: 'Delete', icon: 'trash-2', danger: true },
  ];
  return (
    <div>
      <ContextMenu state={ctx.state} onClose={ctx.close} />
      <PageHeader title="Tickets"
        action={<Button variant="primary" icon={<Icon name="plus" size={16} />}>New ticket</Button>} />
      <div style={{ maxWidth: 240, marginBottom: 20 }}>
        <Select value={filter} onChange={e => setFilter(e.target.value)}
          options={['All statuses', 'Open', 'In progress', 'Waiting', 'Resolved', 'Closed']} />
      </div>
      <BulkBar count={s.count} onClear={s.clear} actions={[
        { label: 'Assign', icon: 'user-plus', onClick: s.clear },
        { label: 'Resolve', icon: 'check', onClick: s.clear },
        { label: 'Close', icon: 'archive', onClick: s.clear },
        { label: 'Delete', icon: 'trash-2', danger: true, onClick: s.clear },
      ]} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 4px 10px' }}>
        <Checkbox checked={s.all} indeterminate={s.some} onChange={s.toggleAll} ariaLabel="Select all tickets" />
        <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Select all</span>
      </div>
      {TICKETS.map(t => (
        <Card key={t.id} pad={0} hoverable onContextMenu={(e) => ctx.open(e, menuFor(t))} style={{ marginBottom: 12 }}>
          <div style={{ padding: '16px 20px', display: 'flex', gap: 16, alignItems: 'flex-start', background: s.has(t.id) ? 'var(--brand-soft)' : 'transparent', borderRadius: 'var(--radius-md)' }}>
            <div style={{ paddingTop: 2 }}><Checkbox checked={s.has(t.id)} onChange={(e) => s.toggle(t.id, e)} ariaLabel={`Select ${t.subject}`} /></div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                    <span style={{ fontWeight: 600, fontSize: 15, color: 'var(--text-heading)' }}>{t.subject}</span>
                    <Badge tone="neutral">{t.dept}</Badge>
                  </div>
                  <p style={{ margin: '6px 0 0', fontSize: 12, color: 'var(--text-muted)', fontStyle: 'italic', display: 'flex', alignItems: 'center', gap: 6 }}>
                    <Icon name="message-square" size={12} /> {t.last} <span>· {t.ago}</span>
                  </p>
                </div>
                <Badge tone={t.stone}>{STATUS_LABEL[t.status]}</Badge>
              </div>
              <div style={{ display: 'flex', gap: 16, marginTop: 10, fontSize: 13, color: 'var(--text-subtle)' }}>
                <span style={{ color: `var(--status-${t.ptone === 'neutral' ? 'waiting' : t.ptone})`, fontWeight: 600, textTransform: 'capitalize' }}>{t.priority}</span>
                <span>{t.date}</span>
              </div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

const CONTACTS = [
  { name: 'Lotte de Vries', email: 'finance@acmebv.com', company: 'Acme BV', phone: '+31 20 555 0142' },
  { name: 'Marco Jansen', email: 'ops@techcorp.io', company: 'TechCorp', phone: '+31 6 1234 5678' },
  { name: 'Sara Nordström', email: 'sara@nordex.io', company: 'Nordex', phone: '—' },
  { name: 'Bloom Agency', email: 'hello@bloom.agency', company: 'Bloom Agency', phone: '+44 20 7946 0991' },
  { name: 'Ridley Co', email: 'support@ridley.co', company: 'Ridley Co', phone: '+1 415 555 0117' },
];

function ContactList() {
  const [q, setQ] = React.useState('');
  const rows = CONTACTS.filter(c => (c.name + c.email + c.company).toLowerCase().includes(q.toLowerCase()));
  const ids = rows.map(c => c.email);
  const s = useSelection(ids);
  const ctx = useContextMenu();
  const menuFor = (c) => [
    { header: c.name },
    { label: 'View contact', icon: 'user' },
    { label: 'Send email', icon: 'mail' },
    { label: 'Add to pipeline', icon: 'kanban' },
    { label: 'Add label\u2026', icon: 'tag' },
    { separator: true },
    { label: 'Export', icon: 'download' },
    { label: 'Delete contact', icon: 'trash-2', danger: true },
  ];
  return (
    <div>
      <ContextMenu state={ctx.state} onClose={ctx.close} />
      <PageHeader title="Contacts"
        action={<Button variant="primary" icon={<Icon name="plus" size={16} />}>New contact</Button>} />
      <div style={{ maxWidth: 400, marginBottom: 20 }}>
        <Input placeholder="Search by name, email, or company…" value={q}
          onChange={e => setQ(e.target.value)} icon={<Icon name="search" size={16} />} />
      </div>
      <BulkBar count={s.count} onClear={s.clear} actions={[
        { label: 'Add label', icon: 'tag', onClick: s.clear },
        { label: 'Add to pipeline', icon: 'kanban', onClick: s.clear },
        { label: 'Export', icon: 'download', onClick: s.clear },
        { label: 'Delete', icon: 'trash-2', danger: true, onClick: s.clear },
      ]} />
      <Card pad={0}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border-default)', textAlign: 'left' }}>
              <th style={{ padding: '12px 16px', width: 40 }}>
                <Checkbox checked={s.all} indeterminate={s.some} onChange={s.toggleAll} ariaLabel="Select all contacts" />
              </th>
              {['Name', 'Email', 'Company', 'Phone'].map(h => (
                <th key={h} style={{ padding: '12px 16px', fontWeight: 600, color: 'var(--slate-600)', fontSize: 13 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(c => (
              <tr key={c.email} onContextMenu={(e) => ctx.open(e, menuFor(c))} style={{ borderBottom: '1px solid var(--border-subtle)', background: s.has(c.email) ? 'var(--brand-soft)' : 'transparent' }}>
                <td style={{ padding: '12px 16px' }}>
                  <Checkbox checked={s.has(c.email)} onChange={(e) => s.toggle(c.email, e)} ariaLabel={`Select ${c.name}`} />
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <Avatar name={c.name} size={28} />
                    <a href="#" style={{ color: 'var(--brand)', fontWeight: 500 }}>{c.name}</a>
                  </div>
                </td>
                <td style={{ padding: '12px 16px', color: 'var(--text-subtle)' }}>{c.email}</td>
                <td style={{ padding: '12px 16px', color: 'var(--text-subtle)' }}>{c.company}</td>
                <td style={{ padding: '12px 16px', color: 'var(--text-subtle)' }}>{c.phone}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <p style={{ marginTop: 12, fontSize: 13, color: 'var(--text-muted)' }}>{rows.length} of {CONTACTS.length} contacts</p>
    </div>
  );
}

const INVOICES = [
  { id: 'INV-0421', client: 'Acme BV', amount: '€240.00', status: 'overdue', stone: 'urgent', due: 'Due 14 Jun 2026' },
  { id: 'INV-0420', client: 'TechCorp', amount: '€180.00', status: 'sent', stone: 'info', due: 'Due 28 Jun 2026' },
  { id: 'INV-0419', client: 'Nordex', amount: '€529.00', status: 'paid', stone: 'success', due: 'Paid 12 Jun 2026' },
  { id: 'INV-0418', client: 'Bloom Agency', amount: '€97.00', status: 'draft', stone: 'neutral', due: 'Not sent' },
  { id: 'INV-0417', client: 'Ridley Co', amount: '€205.00', status: 'paid', stone: 'success', due: 'Paid 9 Jun 2026' },
];

function BillingList() {
  const ids = INVOICES.map(i => i.id);
  const s = useSelection(ids);
  const ctx = useContextMenu();
  const menuFor = (inv) => [
    { header: inv.id },
    { label: 'View invoice', icon: 'file-text' },
    { label: 'Send reminder', icon: 'bell' },
    { label: 'Mark as paid', icon: 'check' },
    { label: 'Duplicate', icon: 'copy' },
    { separator: true },
    { label: 'Download PDF', icon: 'download' },
    { label: 'Delete', icon: 'trash-2', danger: true },
  ];
  return (
    <div>
      <ContextMenu state={ctx.state} onClose={ctx.close} />
      <PageHeader title="Billing" subtitle="Invoices sent and tracked without leaving Yippie."
        action={<Button variant="primary" icon={<Icon name="plus" size={16} />}>New invoice</Button>} />
      <BulkBar count={s.count} onClear={s.clear} actions={[
        { label: 'Send reminder', icon: 'bell', onClick: s.clear },
        { label: 'Mark paid', icon: 'check', onClick: s.clear },
        { label: 'Export', icon: 'download', onClick: s.clear },
        { label: 'Delete', icon: 'trash-2', danger: true, onClick: s.clear },
      ]} />
      <Card pad={0}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border-default)', textAlign: 'left' }}>
              <th style={{ padding: '12px 16px', width: 40 }}>
                <Checkbox checked={s.all} indeterminate={s.some} onChange={s.toggleAll} ariaLabel="Select all invoices" />
              </th>
              {['Invoice', 'Client', 'Amount', 'Status', 'Due'].map(h => (
                <th key={h} style={{ padding: '12px 16px', fontWeight: 600, color: 'var(--slate-600)', fontSize: 13 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {INVOICES.map(i => (
              <tr key={i.id} onContextMenu={(e) => ctx.open(e, menuFor(i))} style={{ borderBottom: '1px solid var(--border-subtle)', background: s.has(i.id) ? 'var(--brand-soft)' : 'transparent' }}>
                <td style={{ padding: '12px 16px' }}>
                  <Checkbox checked={s.has(i.id)} onChange={(e) => s.toggle(i.id, e)} ariaLabel={`Select ${i.id}`} />
                </td>
                <td style={{ padding: '12px 16px' }}><span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--text-heading)' }}>{i.id}</span></td>
                <td style={{ padding: '12px 16px', color: 'var(--text-subtle)' }}>{i.client}</td>
                <td style={{ padding: '12px 16px', fontWeight: 600, color: 'var(--text-heading)' }}>{i.amount}</td>
                <td style={{ padding: '12px 16px' }}><Badge tone={i.stone}>{i.status}</Badge></td>
                <td style={{ padding: '12px 16px', color: 'var(--text-muted)', fontSize: 13 }}>{i.due}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

Object.assign(window, { TicketList, ContactList, BillingList });
