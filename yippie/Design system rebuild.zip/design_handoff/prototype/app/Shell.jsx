const { Button, Input } = window.YippieDesign_488656;
const { Icon } = window;

const NAV = [
  { id: 'inbox', label: 'Inbox', icon: 'inbox', dot: true, badge: '3' },
  { id: 'contacts', label: 'Contacts', icon: 'users' },
  { id: 'tickets', label: 'Tickets', icon: 'clipboard-list', red: '2' },
  { id: 'calendar', label: 'Calendar', icon: 'calendar' },
  { id: 'chat', label: 'Live Chat', icon: 'message-square', green: '5' },
  { id: 'activity', label: 'Activity', icon: 'activity' },
  { id: 'billing', label: 'Billing', icon: 'credit-card' },
];

function Sidebar({ view, setView }) {
  const baseView = view === 'draft' ? 'inbox' : view;
  const itemStyle = (active) => ({
    width: '100%', display: 'flex', alignItems: 'center', gap: 12,
    padding: '10px 12px', border: 'none', cursor: 'pointer', textAlign: 'left',
    fontFamily: 'var(--font-body)', fontSize: 14, fontWeight: active ? 600 : 500,
    borderRadius: 'var(--radius-md)',
    color: active ? '#fff' : 'rgba(255,255,255,0.75)',
    background: active ? 'rgba(255,255,255,0.20)' : 'transparent',
    transition: 'background 150ms ease, color 150ms ease',
  });
  const pill = (bg, fg) => ({ background: bg, color: fg, fontSize: 10, fontWeight: 700,
    minWidth: 18, height: 18, borderRadius: 999, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', padding: '0 5px' });

  return (
    <aside style={{ width: 'var(--sidebar-width)', minHeight: '100vh', background: 'var(--brand)',
      display: 'flex', flexDirection: 'column', flexShrink: 0, position: 'sticky', top: 0, overflowY: 'auto' }}>
      <div style={{ padding: '22px 16px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 44, height: 44, borderRadius: 'var(--radius-md)', background: '#fff',
          boxShadow: '0 2px 6px rgba(11,17,32,0.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <img src="../../assets/logo-mark-tight.svg" alt="Yippie" style={{ width: 30, height: 30, display: 'block' }} />
        </div>
        <div style={{ minWidth: 0 }}>
          <p style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 700, color: '#fff', letterSpacing: '-0.01em' }}>Yippie</p>
          <p style={{ margin: 0, fontSize: 12, fontWeight: 500, color: 'rgba(255,255,255,0.7)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>Acme BV</p>
        </div>
      </div>
      <nav style={{ flex: 1, padding: '0 8px', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV.map(n => {
          const active = baseView === n.id;
          return (
            <button key={n.id} onClick={() => setView(n.id)} style={itemStyle(active)}>
              <Icon name={n.icon} size={16} stroke={2} color="currentColor" />
              <span style={{ flex: 1 }}>{n.label}</span>
              {n.dot ? <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#22c55e' }} /> : null}
              {n.badge ? <span style={pill('#fff', 'var(--brand-deep)')}>{n.badge}</span> : null}
              {n.red ? <span style={pill('#ef4444', '#fff')}>{n.red}</span> : null}
              {n.green ? <span style={pill('#22c55e', '#fff')}>{n.green}</span> : null}
            </button>
          );
        })}
      </nav>
      <div style={{ borderTop: '1px solid rgba(255,255,255,0.15)', padding: '12px 8px', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {[{ id: 'profile', label: 'Profile', icon: 'user-circle' }, { id: 'settings', label: 'Settings', icon: 'settings' }].map(s => (
          <button key={s.id} onClick={() => setView('settings')} style={itemStyle(false)}>
            <Icon name={s.icon} size={16} stroke={2} color="currentColor" /><span>{s.label}</span>
          </button>
        ))}
        <div style={{ padding: '8px 12px 0' }}>
          <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', margin: '4px 0 8px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>diederik@getyippie.com</p>
          <button style={{ display: 'inline-flex', alignItems: 'center', gap: 8, border: 'none', background: 'transparent',
            color: 'rgba(255,255,255,0.7)', fontSize: 14, fontWeight: 500, cursor: 'pointer', fontFamily: 'var(--font-body)', padding: 0 }}>
            <Icon name="log-out" size={14} stroke={2} color="currentColor" /> Sign out
          </button>
        </div>
      </div>
    </aside>
  );
}

function LoginScreen({ onLogin }) {
  return (
    <div className="bgGrid" style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, background: 'var(--off-white)', padding: 24 }}>
      <img src="../../assets/logo-lockup-onLight.svg" alt="Yippie" style={{ height: 132, width: 'auto', display: 'block', marginBottom: 4 }} />
      <div style={{ width: 400, maxWidth: '100%', background: '#fff', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)',
        border: '1px solid var(--border-default)', padding: 38 }}>
        <p style={{ margin: '0 0 8px', fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600, color: 'var(--brand-deep)' }}>// Sign in</p>
        <h1 style={{ margin: '0 0 4px', fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--ink)' }}>Welcome back</h1>
        <p style={{ margin: '0 0 24px', fontSize: 14, color: 'var(--text-subtle)' }}>Log in to your Yippie workspace.</p>
        <form onSubmit={e => { e.preventDefault(); onLogin(); }} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Input label="Email" type="email" defaultValue="diederik@getyippie.com" icon={<Icon name="mail" size={16} />} />
          <Input label="Password" type="password" defaultValue="password" icon={<Icon name="lock" size={16} />} />
          <div style={{ marginTop: 4 }}>
            <Button type="submit" variant="primary" fullWidth iconRight={<Icon name="arrow-right" size={16} />}>Sign in</Button>
          </div>
        </form>
      </div>
    </div>
  );
}

function PageHeader({ title, subtitle, action }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: subtitle ? 16 : 24, gap: 16 }}>
      <div>
        <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--ink)' }}>{title}</h1>
        {subtitle ? <p style={{ margin: '6px 0 0', fontSize: 14, color: 'var(--text-subtle)' }}>{subtitle}</p> : null}
      </div>
      {action}
    </div>
  );
}

function Placeholder({ title, icon }) {
  return (
    <div>
      <PageHeader title={title} />
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        padding: '80px 0', color: 'var(--text-muted)', gap: 12 }}>
        <Icon name={icon} size={40} stroke={1.25} />
        <p style={{ margin: 0, fontSize: 14 }}>The {title} module lives here.</p>
      </div>
    </div>
  );
}

Object.assign(window, { Sidebar, LoginScreen, PageHeader, Placeholder });
