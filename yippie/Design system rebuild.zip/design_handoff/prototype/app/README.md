# Support App UI Kit — app.getyippie.com

A recreation of the Yippie customer-service platform (`apps/app/frontend`, React + Vite). The signature flow: an email or WhatsApp message arrives, Yippie's AI drafts a ticket, and the agent reviews → approves it in one click.

## Surfaces
- **icons.jsx** — lucide `Icon` helper.
- **Shell.jsx** — dark slate sidebar (logo-cyan active accent + inbox count badge), the sign-in screen, `PageHeader`, and a `Placeholder` for not-yet-built modules.
- **Inbox.jsx** — `InboxQueue` (Pending/Processed tabs + AI draft cards) and `DraftReview` (original message beside the editable AI-suggested ticket, with Approve / Forward / Reject).
- **Records.jsx** — `TicketList` (status filter, status & priority badges, last-comment preview) and `ContactList` (search + table).
- **index.html** — full click-through: sign in → Inbox → Review a draft → Approve; switch modules via the sidebar.

## Faithful-to-source notes
- Real source: `apps/app/frontend/src` — `shell/Sidebar.tsx`, `modules/inbox/pages/InboxQueue.tsx` + `DraftReview.tsx`, `modules/tickets/pages/TicketList.tsx`, `modules/contacts/pages/ContactList.tsx`.
- Layout, the dark `slate-800` sidebar, status/priority badge palette, and the inbox→draft→ticket flow all mirror the live app.
- **Two intentional upgrades to the brand standard:** (1) sidebar icons use **lucide** (the live app still uses emoji); (2) primary actions use the **Yippie blue** Button (the live app predates the brand refresh and still uses a generic `#2563eb`). Both are documented in the root README under "Known divergences."
