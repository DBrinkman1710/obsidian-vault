/* Icon — renders a lucide glyph as a real SVG (no DOM mutation).
   lucide UMD keys icons in PascalCase; each entry is a full svg node
   ["svg", attrs, [ [tag, attrs], ... ]]. We pull the child tuples. */
function Icon({ name, size = 20, stroke = 1.75, color = 'currentColor', style = {} }) {
  const lib = window.lucide || {};
  const pascal = String(name).replace(/(^|-)([a-z])/g, (_, __, c) => c.toUpperCase());
  const node = (lib.icons && lib.icons[pascal]) || lib[pascal];
  if (!node) return <span style={{ display: 'inline-block', width: size, height: size }} />;
  const children = (Array.isArray(node) && node[0] === 'svg') ? node[2]
    : (node && node.iconNode) ? node.iconNode
    : node;
  const parts = Array.isArray(children) ? children : [];
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
      style={{ display: 'block', flexShrink: 0, ...style }}>
      {parts.map(([tag, attrs], i) => React.createElement(tag, { key: i, ...attrs }))}
    </svg>
  );
}

window.Icon = Icon;
