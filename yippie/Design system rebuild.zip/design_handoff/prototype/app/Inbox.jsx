const { Tabs, Badge, Button, Card } = window.YippieDesign_488656;
const { Icon, PageHeader, useSelection, Checkbox, BulkBar, useContextMenu, ContextMenu } = window;

const DRAFTS = [
  { id: 'd1', source: 'email', subject: 'Invoice INV-0421 — overcharged?', priority: 'high', tone: 'high',
    category: 'Billing', when: '4m ago',
    desc: 'Customer says invoice INV-0421 charged €240 instead of the agreed €180 and is asking for a corrected invoice before paying.',
    from: 'finance@acmebv.com', name: 'Acme BV',
    body: "Hi,\n\nWe just received invoice INV-0421 for €240, but our agreed monthly rate is €180. Could you please send a corrected invoice? We'll settle it the same day.\n\nThanks,\nLotte — Acme BV" },
  { id: 'd2', source: 'whatsapp', subject: 'Login issue — account locked', priority: 'urgent', tone: 'urgent',
    category: 'Account', when: '12m ago',
    desc: 'User locked out after multiple failed login attempts, needs urgent access to pull a report for a client meeting in an hour.',
    from: '+31 6 1234 5678', name: 'TechCorp',
    body: "Hi! I'm locked out of my account after a few wrong password tries. I have a client meeting in an hour and need a report. Can you unlock me asap?" },
  { id: 'd3', source: 'email', subject: 'Pricing plan upgrade to Growth', priority: 'low', tone: 'neutral',
    category: 'Sales', when: '1h ago',
    desc: 'Existing Starter customer wants to upgrade to the Growth plan and asks whether annual billing is available.',
    from: 'ops@nordex.io', name: 'Nordex',
    body: "Hello, we'd like to move from Starter to Growth. Is annual billing available, and would the −20% apply immediately?" },
];

const SOURCE_ICON = { email: 'mail', whatsapp: 'message-circle' };

function InboxQueue({ openDraft }) {
  const [tab, setTab] = React.useState('pending');
  const ids = DRAFTS.map(d => d.id);
  const s = useSelection(ids);
  const ctx = useContextMenu();
  const menuFor = (d) => [
    { header: d.name },
    { label: 'Review draft', icon: 'arrow-right', onClick: () => openDraft(d.id) },
    { label: 'Approve & create ticket', icon: 'check' },
    { label: 'Forward', icon: 'corner-up-right' },
    { separator: true },
    { label: 'Mark as read', icon: 'mail-open' },
    { label: 'Snooze', icon: 'clock', shortcut: 'S' },
    { separator: true },
    { label: 'Reject', icon: 'x-circle', danger: true },
  ];
  return (
    <div>
      <ContextMenu state={ctx.state} onClose={ctx.close} />
      <PageHeader title="Inbox" subtitle="Messages from email and WhatsApp — review AI drafts before creating tickets." />
      <div style={{ marginBottom: 20 }}>
        <Tabs value={tab} onChange={setTab}
          tabs={[{ value: 'pending', label: 'Pending', count: 3 }, { value: 'processed', label: 'Processed' }]} />
      </div>

      {tab === 'processed' ? (
        <p style={{ color: 'var(--text-muted)', fontSize: 14, padding: '20px 0' }}>No processed drafts yet today.</p>
      ) : (
      <React.Fragment>
        <BulkBar count={s.count} onClear={s.clear} actions={[
          { label: 'Approve', icon: 'check', onClick: s.clear },
          { label: 'Forward', icon: 'corner-up-right', onClick: s.clear },
          { label: 'Reject', icon: 'x-circle', danger: true, onClick: s.clear },
        ]} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 4px 10px' }}>
          <Checkbox checked={s.all} indeterminate={s.some} onChange={s.toggleAll} ariaLabel="Select all drafts" />
          <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Select all</span>
        </div>
        {DRAFTS.map(d => (
        <Card key={d.id} pad={0} hoverable onClick={() => openDraft(d.id)} onContextMenu={(e) => ctx.open(e, menuFor(d))} style={{ marginBottom: 12, cursor: 'pointer' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', padding: '16px 20px', gap: 16, background: s.has(d.id) ? 'var(--brand-soft)' : 'transparent', borderRadius: 'var(--radius-md)' }}>
            <div style={{ paddingTop: 2 }}><Checkbox checked={s.has(d.id)} onChange={(e) => s.toggle(d.id, e)} ariaLabel={`Select ${d.subject}`} /></div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, flexWrap: 'wrap' }}>
                <span style={{ color: 'var(--text-muted)', display: 'flex' }}><Icon name={SOURCE_ICON[d.source]} size={15} /></span>
                <span style={{ fontWeight: 600, color: 'var(--text-heading)', fontSize: 15 }}>{d.subject}</span>
                <Badge tone={d.tone}>{d.priority}</Badge>
                <Badge tone="neutral">{d.category}</Badge>
              </div>
              <p style={{ margin: '0 0 4px', fontSize: 13, color: 'var(--text-subtle)', lineHeight: 'var(--leading-relaxed)' }}>{d.desc}</p>
              <p style={{ margin: 0, fontSize: 12, color: 'var(--text-muted)' }}>{d.name} · {d.when}</p>
            </div>
            <Button size="sm" variant="primary" onClick={(e) => { e.stopPropagation(); openDraft(d.id); }} iconRight={<Icon name="arrow-right" size={14} />}>Review</Button>
          </div>
        </Card>
        ))}
      </React.Fragment>
      )}
    </div>
  );
}

function DraftReview({ id, back }) {
  const d = DRAFTS.find(x => x.id === id) || DRAFTS[0];
  const [priority, setPriority] = React.useState(d.priority);
  const priorities = ['low', 'medium', 'high', 'urgent'];
  const ptone = { low: 'neutral', medium: 'info', high: 'high', urgent: 'urgent' };
  return (
    <div>
      <button onClick={back} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, border: 'none',
        background: 'transparent', color: 'var(--text-subtle)', cursor: 'pointer', fontSize: 13, fontWeight: 600,
        fontFamily: 'var(--font-sans)', padding: 0, marginBottom: 16 }}>
        <Icon name="arrow-left" size={16} /> Back to inbox
      </button>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, alignItems: 'start' }}>
        {/* Original message */}
        <Card pad={20}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <Icon name={SOURCE_ICON[d.source]} size={16} color="var(--text-subtle)" />
            <span style={{ fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>
              Original message
            </span>
          </div>
          <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-heading)' }}>{d.name}</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 14 }}>{d.from}</div>
          <p style={{ margin: 0, fontSize: 14, color: 'var(--text-body)', lineHeight: 'var(--leading-relaxed)', whiteSpace: 'pre-wrap' }}>{d.body}</p>
        </Card>

        {/* AI draft */}
        <Card pad={20} style={{ borderColor: 'var(--yippie-200)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <span style={{ display: 'inline-flex', color: 'var(--brand)' }}><Icon name="sparkles" size={16} /></span>
            <span style={{ fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--brand)' }}>
              AI-drafted ticket
            </span>
          </div>

          <Field label="Subject"><div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-heading)' }}>{d.subject}</div></Field>
          <Field label="Priority">
            <div style={{ display: 'flex', gap: 8 }}>
              {priorities.map(p => (
                <button key={p} onClick={() => setPriority(p)} style={{
                  padding: '4px 10px', borderRadius: 'var(--radius-full)', fontSize: 12, fontWeight: 600,
                  cursor: 'pointer', textTransform: 'capitalize', fontFamily: 'var(--font-sans)',
                  border: priority === p ? '1px solid transparent' : '1px solid var(--border-default)',
                  background: priority === p ? 'var(--brand)' : 'var(--surface-card)',
                  color: priority === p ? 'var(--white)' : 'var(--text-subtle)',
                }}>{p}</button>
              ))}
            </div>
          </Field>
          <Field label="Category"><Badge tone="neutral">{d.category}</Badge></Field>
          <Field label="Description">
            <p style={{ margin: 0, fontSize: 14, color: 'var(--text-body)', lineHeight: 'var(--leading-relaxed)' }}>{d.desc}</p>
          </Field>

          <div style={{ display: 'flex', gap: 10, marginTop: 20, paddingTop: 16, borderTop: '1px solid var(--border-subtle)' }}>
            <Button variant="primary" icon={<Icon name="check" size={16} />} onClick={back}>Approve &amp; create ticket</Button>
            <Button variant="secondary" onClick={back}>Forward</Button>
            <Button variant="ghost" onClick={back}>Reject</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--slate-500)', marginBottom: 6 }}>{label}</div>
      {children}
    </div>
  );
}

Object.assign(window, { InboxQueue, DraftReview });
