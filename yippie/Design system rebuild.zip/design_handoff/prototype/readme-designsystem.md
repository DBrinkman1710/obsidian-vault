# Yippie Design System

The design system for **Yippie** — an AI-assisted, multi-tenant customer-service platform for small and mid-size businesses. Yippie auto-drafts a support ticket from every incoming email or WhatsApp message; the agent reviews and approves it in one click. The positioning: *"Your growth partner in customer service — take back the time that matters."*

This system encodes the **refreshed** brand (the "premium-light tech" direction on the `sandbox` branch) across both Yippie surfaces so any agent can design on-brand screens, slides, and marketing without re-deriving the look.

## Products represented
- **Support platform** — `app.getyippie.com`. React + Vite frontend, FastAPI backend, multi-tenant (one deployment serves all clients, isolated by `tenant_id`). Modules: Inbox (AI drafts), Contacts, Tickets, Calendar/Bookings, Live Chat, Activity, Billing, Kanban/Pipeline. Recreated in `ui_kits/app/`.
- **Marketing site** — `getyippie.com`. Next.js 14 + Tailwind. The polished, canonical expression of the brand. Recreated in `ui_kits/marketing/`.

## Sources (for deeper reference)
- **GitHub:** `github.com/DBrinkman1710/obsidian-vault`, branch **`sandbox`**, monorepo under `yippie/`.
  - Marketing tokens: `yippie/apps/web/src/app/globals.css` (the single source of truth for brand vars), `layout.tsx` (the three `next/font/google` families), `page.module.css`, `page.tsx`.
  - Icons: `yippie/apps/web/src/app/components/icons.tsx` (inline line set, stroke 1.6).
  - App shell: `yippie/apps/app/frontend/src/shell/Sidebar.tsx` (the Yippie-blue sidebar), `App.tsx` (module routes), `modules/inbox/…`, `modules/calendar/…`, `modules/chat/…`.
  - Logos: the repo-root `Logo files/` folder.
- The reader is not assumed to have repo access; these paths are recorded in case they do.

---

## CONTENT FUNDAMENTALS

**Voice — warm, direct, and benefit-first.** Yippie sells *time back* and *growth*, not features. Copy leads with the outcome ("Take back the time that matters", "From email to resolved — in seconds") and keeps sentences short and plain. No hype, no jargon, no buzzwords.

- **Person:** Second person — "**you** / **your** inbox / give **yourself** back time." The product is "Yippie," referred to by name ("Yippie auto-drafts…", "Yippie's AI reads every message").
- **Positioning:** "**Your growth partner in customer service.**" The brand leans on growth promises — *unlimited contacts on every plan*, transparent pricing, reachable founders. "We grow when you grow."
- **Casing:** **Sentence case** everywhere — headings, buttons, nav. The only non-sentence type is the **mono eyebrow** (`// Features`, `// How it works`, `// Pricing`) and tiny uppercase meta labels.
- **Tone:** Confident and calm. Short declaratives, often three-beat: *"Review, approve, done."* Em-dashes for asides — *"Full customer history — emails, tickets, invoices — at a glance."*
- **Emoji:** **None** in brand surfaces (icons do that job).
- **Numbers & proof:** Concrete, modest, scannable — "10h+ saved per week on average", "< 2 min average response time", "6 modules, one platform". Prices in euros (Founder €29 / Starter €79 / Growth €199 / Enterprise custom).
- **CTAs:** Action + arrow — "Start growing with us →", "Start for free →", "Request demo →", "See the product". Meta line under hero CTAs: "No credit card · Unlimited contacts · Cancel anytime".

---

## VISUAL FOUNDATIONS

**Overall vibe:** clean, bright, modern SaaS with a quiet "tech" edge. White and off-white surfaces, one confident blue accent, an **ink/near-black for primary actions and headings**, generous whitespace, soft-rounded corners, restrained cool shadows, and a faint slate grid/dot texture. Friendly but precise — never playful-cartoonish, never enterprise-heavy.

### Color
- **One brand color: Yippie blue `#5BA4F5`** (`--brand` / `--yippie-500`). It carries links, mono eyebrows, the big stat numbers, active states, focus rings, the app sidebar, and the *hover* state of primary buttons. 600 (`#3D8DE8`) for hover, 700 (`#2E74C9`) for blue text on light, 50–100 for tinted chips and glows.
- **Ink is the primary-action color.** `--ink` `#0F172A` backs primary buttons and headings, and **warms to Yippie blue on hover** with a soft 2px lift + `--shadow-brand`. This ink→blue button is the signature interaction of the refreshed brand (don't default primaries to solid blue).
- **Neutrals: the full Tailwind slate ramp.** slate-900/ink headings, slate-700 body, slate-500/400 muted & meta, hairline borders `#e7ebf0`, off-white `#f8fafc` page bands.
- **Dark surfaces** use a deep navy: `--dark` `#0b1120` (product-moment sections, footer) and `--dark-2` `#111a2e`.
- **Status palette** (soft tinted bg + full-strength text): red-600 urgent, amber-600 high/in-progress, blue-500 open/info, green-600 resolved, violet-600 waiting/forwarded.
- Hierarchy is built from **slate + ink + one blue** — there is no secondary brand hue. Resist purple/teal/gradient accents.

### Typography
- **Three families** (all `next/font/google` on the live site):
  - **Space Grotesk** (500/600/700) — display & headings, tight tracking (`-0.025` to `-0.03em`). `--font-display`.
  - **Inter** (400–700) — body & UI at relaxed line-height (1.7 on marketing). `--font-body`.
  - **JetBrains Mono** (500/600) — eyebrows, meta labels, IDs, URLs, the hero pill. `--font-mono`.
- Display hero is large (clamp to ~70px) and tight-leading (1.04). App page titles are ~26/700 Space Grotesk. Body UI text is 14px Inter. **Eyebrows are mono, 12–13px, with a `// ` prefix** in deep Yippie blue (bright blue on dark) — *not* uppercase letter-spaced labels.

### Shape, depth & spacing
- **Corner radii:** `--radius-sm` 8 (buttons, inputs, list rows) · `md` 12 (cards, feature tiles) · `lg` 16 (product frame) · `xl` 22 (CTA cards) · `full` (pills/avatars/toggles).
- **Cards:** white, **1px hairline border** (`#e7ebf0`), soft `--shadow-sm`. Hover lifts to `--shadow-md` + a 3px rise. The featured pricing card swaps the border for a Yippie-blue ring with a "Most popular" pill; the founding tier gets a "Founding Member" pill.
- **Shadows are cool and slate-tinted** and *layered* (e.g. `--shadow-md` = a tight + a wide rgba(15,23,42,…) pair). `--shadow-2xl` is reserved for product mockups; `--shadow-brand` (blue, soft) is the lifted-primary-button glow.
- **Spacing** on a 4px grid. Marketing sections pad ~96px vertical with a `6vw` gutter; the app content area pads 32px. Max marketing width 1180px. App sidebar is a fixed 220px.

### Backgrounds, imagery & motifs
- **No photography, no illustration.** Backgrounds are flat: white, off-white, deep navy (`--dark`), or solid Yippie blue (the app sidebar).
- **The signature texture** is a faint slate **grid** (`.bgGrid`, 56px) or **dot field** (`.bgDots`, 24px) laid under flat sections — the quiet "tech" cue of the refreshed brand. Dark sections use `.bgDotsDark` plus one soft blurred Yippie-blue glow (radial, ~10px blur). Used sparingly.
- The "imagery" is **UI-of-itself**: a light browser-chrome mockup of the inbox (with a blue mini-sidebar) reused in the hero and the dark product moment. Build these from real components, not screenshots.
- **Gradients:** essentially none — solid fills only. (One exception: the CTA card's faint radial blue wash, and the featured-card ring.)

### Motion & states
- **Subtle and quick.** Scroll-reveal is a short fade + 14px rise (`0.6s` premium ease `cubic-bezier(0.22,1,0.36,1)`), staggered ~70–90ms. No bounces, no springs, no parallax. Reveal must degrade to visible for print/reduced-motion.
- **Hover:** primary buttons shift ink→blue and lift 2px with `--shadow-brand`; secondary buttons deepen their border to brand blue and lift; ghost items get a slate wash; cards raise their shadow + rise; links go slate→ink.
- **Press:** the lift returns to 0. **Focus:** Yippie-blue border + a soft 3px `rgba(91,164,245,0.3)` ring (`--ring-brand`).
- **Transparency/blur** appears in the hero glow, the nav's blurred backdrop, and the sign-up modal scrim (`rgba(15,24,36,0.55)` + `blur(4px)`).

---

## ICONOGRAPHY

- **Lucide is the icon system** — the brand standard on both surfaces. Thin, rounded line icons, stroke weight **1.6–2** at ~16–22px, drawn in `currentColor` (slate, Yippie blue, or white on the blue sidebar).
- Common glyphs: `inbox`, `users`, `clipboard-list` (tickets), `calendar`, `kanban`, `message-square` (live chat), `activity`, `credit-card` (the modules); `mail`, `message-circle` (email/WhatsApp sources); `sparkles` (AI drafts); `arrow-right`, `check`, `plus`, `search`, `send`, `settings`, `log-out`, `user-circle`, `x`, `chevron-left/right`.
- The kits load lucide via CDN (`unpkg.com/lucide@0.460.0`) and render glyphs through the small `Icon` helper in `ui_kits/*/icons.jsx`. For production, install `lucide-react`.
- **Emoji:** not part of the brand. **No custom/hand-drawn SVG icons, no icon fonts, no unicode-as-icon.**
- **Logo:** a **clock-to-network** mark — clock hands blooming into a constellation of connected nodes (time, reclaimed, becoming growth) — paired with the lowercase **yippie** wordmark and a "CUSTOMER PLATFORM" tagline. Background-locked tiles ship in `assets/` (white / ink / blue); transparent lockups (`logo-lockup-onLight/onDark`), tight nav crops (`logo-nav-onLight/onDark`), and mark-only files are also provided. Keep clearspace ≈ the mark's height; don't recolor the mark.

---

## Index / manifest

**Root**
- `styles.css` — the single entry point consumers link. `@import`s every token file (order: fonts → colors → typography → spacing → radii → base).
- `readme.md` — this guide. `SKILL.md` — portable Agent-Skill wrapper.

**`tokens/`** — `fonts.css` (Space Grotesk + Inter + JetBrains Mono), `colors.css`, `typography.css`, `spacing.css`, `radii.css` (radii + shadows), `base.css` (reset + `.bgGrid`/`.bgDots`/`.bgDotsDark` + scroll-reveal). All custom properties on `:root`.

**`assets/`** — logo tiles (`logo-white-bg` / `logo-black-bg` / `logo-blue-bg`, `.svg` + `.png`), transparent lockups, tight nav crops, mark-only variants, and `favicon.svg`.

**`components/`** (React primitives — `window.YippieDesign_488656.<Name>`)
- `core/` — Button (ink→blue), IconButton, Badge, Card, Avatar, Stat, Eyebrow (mono `// `)
- `forms/` — Input, Select, Toggle
- `navigation/` — Tabs
- Each has a `.d.ts` (props), `.prompt.md` (usage), and a `@dsCard` demo HTML.

**`guidelines/`** — foundation specimen cards (Colors incl. Ink & Action, Type incl. Mono, Spacing, Brand incl. Logo + Textures) shown in the Design System tab.

**`ui_kits/`**
- `marketing/` — full `getyippie.com` landing page (hero, features, how-it-works, dark product moment, growth partner, 4-tier pricing, CTA, footer; sign-up modal).
- `app/` — the support platform: sign-in → Inbox → AI draft review → Tickets / Contacts / Calendar / Live Chat, behind the Yippie-blue sidebar.

> **Fonts caveat:** the three families load via Google Fonts (`@import` in `tokens/fonts.css`), not self-hosted `@font-face` binaries — so the compiler reports 0 bundled fonts. These are the *real* brand fonts (no substitution); to self-host, drop `.woff2` files in `assets/fonts/` and swap the import for `@font-face` rules.
