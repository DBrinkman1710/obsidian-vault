const { Button } = window.YippieDesign_488656;
const { Icon } = window;

const MODULES = [
  { id: 'inbox', kicker: 'INBOX', icon: 'inbox', path: '/inbox', title: 'Smart Inbox — zero manual write-up',
    desc: 'Every incoming email lands in a unified inbox where AI reads the message and instantly drafts the ticket subject, priority, and description. You review, edit if needed, and approve in one click.',
    bullets: ['AI auto-drafts subject, priority, and description', 'Bulk approve, archive, or reassign in one action', 'Shared inbox for the whole team — no CC chains', 'SLA timers start the moment a message arrives'] },
  { id: 'tickets', kicker: 'TICKETS', icon: 'clipboard-list', path: '/tickets', title: 'Tickets — track everything, miss nothing',
    desc: 'Approved messages become structured tickets with an assignee, priority, deadline, and full email history. SLA alerts fire before anything slips, and bulk actions let you triage a dozen issues at once.',
    bullets: ['SLA deadline badges with color-coded urgency', 'Assign to agents or departments with one click', 'Bulk select, reassign, or close at once', 'Full conversation thread lives on the ticket'] },
  { id: 'contacts', kicker: 'CONTACTS', icon: 'users', path: '/contacts', title: 'Contacts — full customer context, always',
    desc: 'Every contact has a complete timeline: all emails, tickets, pipeline stage, and company membership in one view. Labels, company grouping, and CSV import/export mean your CRM lives here.',
    bullets: ['Unified timeline of emails, tickets, and moves', 'Company grouping — link contacts to accounts', 'Custom labels for segmentation and filtering', 'CSV import and export for existing lists'] },
  { id: 'calendar', kicker: 'CALENDAR + BOOKING', icon: 'calendar', path: '/calendar', title: 'Calendar — bookings that confirm themselves',
    desc: 'A monthly calendar shows events, ticket deadlines, and booked meetings in one place. Send a personal booking link so customers pick a slot — confirmation emails go out automatically.',
    bullets: ['Monthly view with events, deadlines, bookings', 'Personal booking links — customers pick a slot', 'Confirmation and reminder emails send automatically', 'Bookings can advance a pipeline contact'] },
  { id: 'pipeline', kicker: 'PIPELINE', icon: 'kanban', path: '/pipeline', title: 'Pipeline — every deal at a glance',
    desc: 'A drag-and-drop Kanban board tracks contacts through custom stages — from first touch to closed deal. Campaign buttons in emails can move a contact to the right stage the moment they click.',
    bullets: ['Fully customisable Kanban stages', 'Drag contacts between stages, instantly saved', 'Campaign buttons auto-advance contacts on click', 'Booking confirmations trigger stage moves'] },
  { id: 'chat', kicker: 'LIVE CHAT', icon: 'message-square', path: '/chat', title: 'Live Chat — one widget, same inbox',
    desc: 'Embed a chat widget on your website with a single script tag. Every visitor conversation lands in the shared inbox alongside email and tickets — your team sees everything in one place.',
    bullets: ['One-line embed script — live in minutes', 'Chats appear in the shared inbox automatically', 'Assign chats to agents or let the team claim them', 'Full chat history attached to the contact'] },
  { id: 'emailtracking', kicker: 'EMAIL TRACKING', icon: 'mail-check', path: '/billing', title: 'Email Tracking — know what landed',
    desc: 'The Sent tab shows real-time delivery status for every outbound email: delivered, opened, clicked, or bounced. Stop guessing whether your follow-up reached the right person.',
    bullets: ['Real-time open, click, and bounce tracking', 'Sent tab with delivery timestamps', 'Bounce alerts so you can fix bad addresses', 'Works on replies and bulk campaign sends'] },
  { id: 'templates', kicker: 'TEMPLATES', icon: 'layout-template', path: '/settings/templates', title: 'Templates — polished emails in seconds',
    desc: 'Build rich HTML email templates with a drag-and-drop editor and save them for the whole team. Add campaign buttons that apply a pipeline stage the moment a customer clicks.',
    bullets: ['Drag-and-drop editor — no HTML needed', 'Team-wide library from any reply window', 'Campaign buttons trigger pipeline moves', 'Preview on desktop and mobile before sending'] },
  { id: 'activity', kicker: 'ACTIVITY', icon: 'activity', path: '/activity', title: 'Activity — your business in real time',
    desc: 'A chronological feed of everything across your workspace: emails sent, tickets updated, contacts moved, bookings confirmed. Always know who did what and when, without asking.',
    bullets: ['Real-time log of every action', 'Filter by event type, user, or date range', 'Links take you straight to context', 'A clean audit trail for accountability'] },
  { id: 'team', kicker: 'TEAM', icon: 'user-cog', path: '/settings/team', title: 'Team — the right person on every ticket',
    desc: 'Invite agents, set their role, and organise them into departments. Tickets and chats route to the right department automatically, so the right person always picks up the right conversation.',
    bullets: ['Role-based permissions — agent, admin, superuser', 'Departments for clean routing', 'Invite members with a single email link', 'Multiple named email signatures per user'] },
];

function PreviewFrame({ icon, path }) {
  return (
    <div style={{ borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-default)', background: '#fff', boxShadow: 'var(--shadow-lg)', overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '11px 14px', background: 'var(--off-white)', borderBottom: '1px solid var(--border-default)' }}>
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#f1a9a0' }} />
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#f4cf86' }} />
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#a7d8a0' }} />
        <span style={{ marginLeft: 10, fontFamily: 'var(--font-mono)', fontSize: 11.5, color: 'var(--text-muted)' }}>app.getyippie.com{path}</span>
      </div>
      <div className="bgDots" style={{ height: 300, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, background: 'var(--off-white)' }}>
        <div style={{ width: 56, height: 56, borderRadius: 'var(--radius-md)', background: 'var(--brand-soft)', color: 'var(--brand-deep)', border: '1px solid var(--brand-ring)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name={icon} size={26} /></div>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-muted)' }}>// {path.replace('/', '')} preview</span>
      </div>
    </div>
  );
}

function ProductPage({ onDemo }) {
  return (
    <React.Fragment>
      <section className="bgGrid" style={{ textAlign: 'center', padding: '110px var(--gutter) 50px', background: '#fff' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: '#fff', border: '1px solid var(--border-default)', boxShadow: 'var(--shadow-sm)',
          borderRadius: 'var(--radius-full)', padding: '6px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 500, color: 'var(--text-muted)', marginBottom: 24 }}>
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--brand)', boxShadow: '0 0 0 4px var(--brand-soft)' }} />The product
        </div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'clamp(36px,5vw,62px)', letterSpacing: '-0.03em', lineHeight: 1.04, color: 'var(--ink)', margin: '0 0 18px' }}>Ten modules. One platform.</h1>
        <p style={{ fontSize: 18, color: 'var(--text-muted)', lineHeight: 1.7, maxWidth: 560, margin: '0 auto 30px' }}>
          Inbox, tickets, contacts, calendar, pipeline, live chat, email tracking, templates, activity, and team — all working together, all in one workspace.
        </p>
        <Button variant="primary" size="lg" iconRight={<Icon name="arrow-right" size={18} />} onClick={onDemo}>Request demo</Button>
      </section>

      {/* sticky module sub-nav */}
      <nav style={{ position: 'sticky', top: 68, zIndex: 20, background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(8px)',
        borderBlock: '1px solid var(--border-default)', padding: '0 var(--gutter)' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', display: 'flex', gap: 4, overflowX: 'auto', padding: '10px 0' }}>
          {MODULES.map(m => (
            <a key={m.id} href={`#${m.id}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 12px', borderRadius: 'var(--radius-full)',
              fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600, color: 'var(--text-subtle)', whiteSpace: 'nowrap', flexShrink: 0 }}>
              <Icon name={m.icon} size={13} />{m.kicker.split(' ')[0]}
            </a>
          ))}
        </div>
      </nav>

      {MODULES.map((m, i) => {
        const alt = i % 2 === 1;
        return (
          <section key={m.id} id={m.id} style={{ padding: '80px var(--gutter)', background: alt ? 'var(--off-white)' : '#fff',
            borderBottom: '1px solid var(--border-default)', scrollMarginTop: 120 }}>
            <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'center' }}>
              <div style={{ order: alt ? 2 : 1 }}>
                <p style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600, color: 'var(--brand-deep)', margin: '0 0 14px' }}>
                  <span style={{ width: 30, height: 30, borderRadius: 'var(--radius-sm)', background: 'var(--brand-soft)', border: '1px solid var(--brand-ring)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Icon name={m.icon} size={16} /></span>
                  // {m.kicker}
                </p>
                <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'clamp(24px,2.6vw,32px)', letterSpacing: '-0.02em', lineHeight: 1.15, color: 'var(--ink)', margin: '0 0 14px' }}>{m.title}</h2>
                <p style={{ fontSize: 15.5, color: 'var(--text-muted)', lineHeight: 1.7, margin: '0 0 20px' }}>{m.desc}</p>
                <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 10, margin: '0 0 24px', padding: 0 }}>
                  {m.bullets.map(b => (
                    <li key={b} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, fontSize: 14, color: 'var(--text-body)', lineHeight: 1.5 }}>
                      <span style={{ color: 'var(--brand-deep)', flexShrink: 0, display: 'flex', marginTop: 2 }}><Icon name="check" size={15} stroke={2.25} /></span>{b}
                    </li>
                  ))}
                </ul>
                <a onClick={onDemo} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontWeight: 600, fontSize: 14, color: 'var(--brand-deep)', cursor: 'pointer' }}>Open in app <Icon name="arrow-right" size={15} /></a>
              </div>
              <div style={{ order: alt ? 1 : 2 }}><PreviewFrame icon={m.icon} path={m.path} /></div>
            </div>
          </section>
        );
      })}

      <section style={{ background: 'var(--dark)', color: '#fff', textAlign: 'center', padding: '100px var(--gutter)' }} className="bgDotsDark">
        <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, color: 'var(--brand)', margin: '0 0 14px' }}>// Ready to try it?</p>
        <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'clamp(28px,3.4vw,44px)', letterSpacing: '-0.025em', lineHeight: 1.12, margin: '0 0 14px' }}>See every module live in your inbox</h2>
        <p style={{ fontSize: 17, color: 'rgba(255,255,255,0.6)', maxWidth: 520, margin: '0 auto 32px', lineHeight: 1.7 }}>Book a personalised demo and watch Yippie connect your inbox, tickets, and pipeline in one clean workspace.</p>
        <Button variant="primary" size="lg" iconRight={<Icon name="arrow-right" size={18} />} onClick={onDemo}>Request demo</Button>
        <p style={{ marginTop: 18, fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'rgba(255,255,255,0.45)' }}>No credit card · Set up in minutes</p>
      </section>
    </React.Fragment>
  );
}

window.ProductPage = ProductPage;
