const { Button } = window.YippieDesign_488656;
const { Icon } = window;

const INBOX_ITEMS = [
  { sender: 'Acme BV', subject: 'Invoice INV-0421 question', dot: '', badge: 'review' },
  { sender: 'TechCorp', subject: 'Login issue — account locked', dot: 'amber', badge: 'review' },
  { sender: 'Nordex', subject: 'Pricing plan upgrade', dot: 'green', badge: 'done' },
  { sender: 'Bloom Agency', subject: 'Onboarding call request', dot: '', badge: 'review' },
];

/* Light, browser-framed product mockup — built from real-looking app chrome.
   Reused in the hero and the dark "product moment". */
function ProductMockup({ wide = false }) {
  const dotColor = { amber: '#f59e0b', green: '#22c55e', '': 'var(--brand)' };
  return (
    <div style={{
      borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-default)',
      background: '#fff', boxShadow: 'var(--shadow-lg)', overflow: 'hidden',
      maxWidth: wide ? 940 : '100%', margin: wide ? '0 auto' : 0,
    }}>
      {/* chrome bar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '11px 14px',
        background: 'var(--off-white)', borderBottom: '1px solid var(--border-default)' }}>
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#f1a9a0' }} />
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#f4cf86' }} />
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#a7d8a0' }} />
        <span style={{ marginLeft: 10, fontFamily: 'var(--font-mono)', fontSize: 11.5, color: 'var(--text-muted)' }}>app.getyippie.com/inbox</span>
      </div>
      {/* app */}
      <div style={{ display: 'flex', height: 384 }}>
        {/* mini sidebar — Yippie blue */}
        <div style={{ width: 54, background: 'var(--brand)', display: 'flex', flexDirection: 'column',
          alignItems: 'center', padding: '16px 0', gap: 8 }}>
          {[true, false, false, false, false, false].map((active, i) => (
            <div key={i} style={{ width: 30, height: 30, borderRadius: 9,
              background: active ? '#fff' : 'rgba(255,255,255,0.22)',
              boxShadow: active ? '0 4px 12px rgba(0,0,0,0.12)' : 'none' }} />
          ))}
        </div>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '14px 18px', borderBottom: '1px solid var(--border-subtle)' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 15, color: 'var(--ink)' }}>Inbox</span>
            <span style={{ width: 26, height: 26, borderRadius: '50%', background: 'linear-gradient(135deg, var(--brand), var(--brand-deep))' }} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', borderBottom: '1px solid var(--border-subtle)' }}>
            {[['Open', '12', 'var(--brand-deep)'], ['Pending', '4', '#d97706'], ['Resolved', '31', '#16a34a']].map(([l, v, c], i) => (
              <div key={l} style={{ padding: '14px 16px', borderRight: i < 2 ? '1px solid var(--border-subtle)' : 'none',
                display: 'flex', flexDirection: 'column', gap: 5 }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, textTransform: 'uppercase',
                  letterSpacing: '0.06em', color: 'var(--text-muted)' }}>{l}</span>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: c }}>{v}</span>
              </div>
            ))}
          </div>
          <div style={{ flex: 1, overflow: 'hidden' }}>
            {INBOX_ITEMS.map(item => (
              <div key={item.sender} style={{ display: 'flex', alignItems: 'center', gap: 11,
                padding: '12px 18px', borderBottom: '1px solid var(--border-subtle)' }}>
                <span style={{ width: 7, height: 7, borderRadius: '50%', background: dotColor[item.dot], flexShrink: 0 }} />
                <span style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.sender}</span>
                  <span style={{ fontSize: 12, color: 'var(--text-muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.subject}</span>
                </span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, fontWeight: 600,
                  padding: '3px 8px', borderRadius: 5, textTransform: 'uppercase', letterSpacing: '0.04em', flexShrink: 0,
                  background: item.badge === 'done' ? 'rgba(34,197,94,0.14)' : 'var(--brand-soft-2)',
                  color: item.badge === 'done' ? '#16a34a' : 'var(--brand-deep)' }}>{item.badge}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Hero({ onCta, onSeeProduct }) {
  return (
    <section id="top" className="bgGrid" style={{ position: 'relative', padding: '132px var(--gutter) 90px', background: '#fff', overflow: 'hidden' }}>
      {/* Zoomed-in logo mark watermark — pulled left so both the clock and the
          "brain" network bloom are visible behind the hero. */}
      <img src="../../assets/logo-mark-tight.svg" alt="" aria-hidden="true" style={{ position: 'absolute',
        top: '50%', left: '14%', transform: 'translateY(-50%)', width: 1040, height: 1040,
        opacity: 0.085, pointerEvents: 'none', zIndex: 0 }} />
      <div style={{ position: 'absolute', top: -160, right: -80, width: 620, height: 620,
        background: 'radial-gradient(circle, rgba(91,164,245,0.16), transparent 62%)', filter: 'blur(10px)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(255,255,255,0) 55%, #fff 100%)', pointerEvents: 'none' }} />
      <div style={{ position: 'relative', zIndex: 1, maxWidth: 'var(--container-max)', margin: '0 auto',
        display: 'grid', gridTemplateColumns: '1.05fr 1fr', gap: 56, alignItems: 'center' }}>
        <div data-reveal className="isVisible">
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: '#fff',
            border: '1px solid var(--border-default)', boxShadow: 'var(--shadow-sm)', borderRadius: 'var(--radius-full)',
            padding: '6px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 500,
            letterSpacing: '0.02em', color: 'var(--text-muted)', marginBottom: 26 }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--brand)', boxShadow: '0 0 0 4px var(--brand-soft)' }} />
            Your growth partner in customer service
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(40px, 5.4vw, 70px)', fontWeight: 700,
            lineHeight: 1.04, letterSpacing: '-0.03em', color: 'var(--ink)', margin: '0 0 22px' }}>
            Take back the time<br />that matters.
          </h1>
          <p style={{ fontSize: 18, lineHeight: 1.7, color: 'var(--text-muted)', maxWidth: 460, margin: '0 0 32px' }}>
            Yippie auto-drafts every support ticket from your inbox — and grows alongside your business. Review, approve, done.
          </p>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
            <Button variant="primary" size="lg" iconRight={<Icon name="arrow-right" size={17} />} onClick={onCta}>Start growing with us</Button>
            <Button variant="secondary" size="lg" onClick={onSeeProduct}>See the product</Button>
          </div>
          <p style={{ marginTop: 18, fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'var(--text-muted)' }}>No credit card · Unlimited contacts · Cancel anytime</p>
        </div>
        <div data-reveal className="isVisible"><ProductMockup /></div>
      </div>
    </section>
  );
}

window.Hero = Hero;
window.ProductMockup = ProductMockup;
