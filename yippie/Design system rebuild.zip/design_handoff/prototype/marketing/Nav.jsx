const { Button, Input } = window.YippieDesign_488656;
const { Icon } = window;

const NAV_LINKS = [
  { label: 'Home', href: 'index.html', page: 'home' },
  { label: 'Product', href: 'product.html', page: 'product' },
  { label: 'Pricing', href: 'pricing.html', page: 'pricing' },
  { label: 'About', href: 'about.html', page: 'about' },
  { label: 'Blog', href: 'blog.html', page: 'blog' },
];

function Nav({ onSignUp, current }) {
  return (
    <nav style={{ position: 'sticky', top: 0, zIndex: 50, background: 'rgba(255,255,255,0.85)',
      backdropFilter: 'blur(8px)', borderBottom: '1px solid var(--border-default)' }}>
      <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 var(--gutter)', height: 68,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <a href="index.html" aria-label="Yippie home" style={{ display: 'flex' }}><img src="../../assets/logo-mark-tight.svg" alt="Yippie" style={{ height: 36 }} /></a>
        <div style={{ display: 'flex', alignItems: 'center', gap: 30 }}>
          {NAV_LINKS.map(l => (
            <a key={l.label} href={l.href} aria-current={current === l.page ? 'page' : undefined}
              style={{ fontSize: 14, fontWeight: current === l.page ? 600 : 500,
                color: current === l.page ? 'var(--ink)' : 'var(--text-body)' }}>{l.label}</a>
          ))}
          <a href="https://app.getyippie.com" style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>Log in</a>
          <Button variant="primary" size="sm" iconRight={<Icon name="arrow-right" size={15} />} onClick={onSignUp}>Request demo</Button>
        </div>
      </div>
    </nav>
  );
}

function SignUpModal({ onClose }) {
  const [status, setStatus] = React.useState('idle');
  const fields = [
    { key: 'name', label: 'Full name', type: 'text', required: true },
    { key: 'email', label: 'Work email', type: 'email', required: true },
    { key: 'company', label: 'Company', type: 'text', required: false },
  ];
  return (
    <div onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      style={{ position: 'fixed', inset: 0, zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 16, background: 'rgba(15,24,36,0.55)', backdropFilter: 'blur(4px)' }}>
      <div style={{ position: 'relative', width: '100%', maxWidth: 420, padding: 34,
        background: '#fff', borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-2xl)' }}>
        <button onClick={onClose} aria-label="Close" style={{ position: 'absolute', top: 18, right: 18, border: 'none',
          background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', display: 'flex' }}><Icon name="x" size={20} /></button>
        {status === 'success' ? (
          <div style={{ textAlign: 'center', padding: '12px 0' }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'var(--brand-subtle)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', color: 'var(--brand-deep)' }}>
              <Icon name="check" size={24} stroke={2.5} />
            </div>
            <h3 style={{ margin: '0 0 8px', fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: 'var(--ink)' }}>You&rsquo;re on the list</h3>
            <p style={{ margin: 0, fontSize: 14, color: 'var(--text-subtle)' }}>I&rsquo;ll be in touch shortly.</p>
            <div style={{ marginTop: 24 }}><Button variant="primary" onClick={onClose}>Close</Button></div>
          </div>
        ) : (
          <React.Fragment>
            <p style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600, color: 'var(--brand-deep)', margin: '0 0 10px' }}>// Get started</p>
            <h2 style={{ margin: '0 0 6px', fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--ink)' }}>Book a demo</h2>
            <p style={{ margin: '0 0 24px', fontSize: 14, color: 'var(--text-subtle)' }}>No credit card. Unlimited contacts. I&rsquo;ll set you up personally.</p>
            <form onSubmit={e => { e.preventDefault(); setStatus('success'); }} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {fields.map(f => <Input key={f.key} label={f.label} type={f.type} required={f.required} />)}
              <div style={{ marginTop: 4 }}>
                <Button type="submit" variant="primary" fullWidth iconRight={<Icon name="arrow-right" size={16} />}>Request access</Button>
              </div>
            </form>
          </React.Fragment>
        )}
      </div>
    </div>
  );
}

function Footer() {
  const cols = [
    { h: 'Product', items: [['Product', 'product.html'], ['Pricing', 'pricing.html'], ['Live chat', 'product.html#chat'], ['Modules', 'product.html']] },
    { h: 'Company', items: [['About', 'about.html'], ['Blog', 'blog.html'], ['Log in', 'https://app.getyippie.com'], ['Contact', 'about.html']] },
    { h: 'Legal', items: [['Privacy', '#'], ['Terms', '#'], ['Security', '#'], ['GDPR', '#']] },
  ];
  return (
    <footer style={{ background: 'var(--dark)', color: '#fff', padding: '72px var(--gutter) 40px' }}>
      <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', display: 'grid',
        gridTemplateColumns: '1.4fr 1fr 1fr 1fr', gap: 40 }}>
        <div>
          <a href="index.html" style={{ display: 'inline-block' }}><img src="../../assets/logo-lockup-onDark.svg" alt="Yippie" style={{ height: 96, width: 'auto', margin: '-16px 0 8px -8px', display: 'block' }} /></a>
          <p style={{ fontSize: 14, lineHeight: 1.7, color: 'rgba(255,255,255,0.55)', maxWidth: 240 }}>
            Your growth partner in customer service. Give yourself back the time that matters.
          </p>
        </div>
        {cols.map(c => (
          <div key={c.h}>
            <p style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 600, letterSpacing: '0.08em',
              textTransform: 'uppercase', color: 'rgba(255,255,255,0.45)', margin: '0 0 16px' }}>{c.h}</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {c.items.map(([label, href]) => (
                <a key={label} href={href} style={{ fontSize: 14, color: 'rgba(255,255,255,0.72)' }}>{label}</a>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div style={{ maxWidth: 'var(--container-max)', margin: '40px auto 0', paddingTop: 24,
        borderTop: '1px solid var(--dark-border)', display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>© 2026 Yippie · getyippie.com</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>Built in the EU · Prices in €</span>
      </div>
    </footer>
  );
}

Object.assign(window, { Nav, SignUpModal, Footer });
