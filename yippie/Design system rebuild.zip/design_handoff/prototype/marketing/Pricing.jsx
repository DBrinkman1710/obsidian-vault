const { Button } = window.YippieDesign_488656;
const { Icon } = window;

/* Real plan model from apps/web/src/app/pricing/page.tsx — unlimited contacts on
   every tier; plans differ by users + AI scans; modules à la carte. Every list is
   exactly 6 rows so the cards stay the same height. */
const TEASER_PLANS = [
  { tier: 'Founder', price: '€9', desc: 'Founding Member — first 5 spots', founding: true,
    features: ['Inbox', 'Contacts', '2 users', 'Unlimited contacts', '500 AI scans/mo', 'Add-ons à la carte'] },
  { tier: 'Starter', price: '€19', desc: 'For small teams',
    features: ['Inbox', 'Contacts', '5 users', 'Unlimited contacts', '2,000 AI scans/mo', 'Add-ons à la carte'] },
  { tier: 'Growth', price: '€49', desc: 'For growing businesses', featured: true,
    features: ['Inbox', 'Contacts', '10 users', 'Unlimited contacts', '10,000 AI scans/mo', 'Add-ons à la carte'] },
  { tier: 'Enterprise', price: 'Custom', desc: 'Dedicated growth partnership',
    features: ['Everything in Growth', 'Tickets + AI + Calendar', 'Kanban + Email tracking', 'Unlimited users', 'Unlimited AI scans', 'Dedicated support'] },
];

function Pricing({ go }) {
  return (
    <section id="pricing" style={{ padding: '96px var(--gutter)', scrollMarginTop: 80 }}>
      <div data-reveal className="isVisible" style={{ maxWidth: 620, margin: '0 auto 56px', textAlign: 'center' }}>
        <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, color: 'var(--brand-deep)', margin: 0 }}>// Pricing</p>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(28px,3.4vw,44px)', fontWeight: 700,
          color: 'var(--ink)', letterSpacing: '-0.025em', lineHeight: 1.12, margin: '14px 0' }}>Scale without limits</h2>
        <p style={{ fontSize: 17, color: 'var(--text-muted)', lineHeight: 1.7, margin: 0 }}>Every plan includes unlimited contacts. Pay for team size and AI power — add modules as you grow.</p>
      </div>
      <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', display: 'grid',
        gridTemplateColumns: 'repeat(4,1fr)', gap: 16, alignItems: 'stretch' }}>
        {TEASER_PLANS.map(p => (
          <div key={p.tier} className="priceCard" style={{ position: 'relative', padding: '30px 26px', borderRadius: 'var(--radius-lg)',
            background: '#fff', display: 'flex', flexDirection: 'column',
            border: p.featured ? '1.5px solid var(--brand)' : '1px solid var(--border-default)',
            boxShadow: p.featured ? 'var(--shadow-md)' : 'none' }}>
            {(p.featured || p.founding) && (
              <span style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)',
                background: 'var(--ink)', color: '#fff', fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 600,
                letterSpacing: '0.06em', textTransform: 'uppercase', padding: '5px 12px', borderRadius: 'var(--radius-full)', whiteSpace: 'nowrap' }}>
                {p.featured ? 'Most popular' : 'Founding Member'}
              </span>
            )}
            <p style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600, letterSpacing: '0.06em',
              textTransform: 'uppercase', color: 'var(--brand-deep)', margin: '0 0 12px' }}>{p.tier}</p>
            <p style={{ fontFamily: 'var(--font-display)', fontSize: 40, fontWeight: 700, color: 'var(--ink)',
              letterSpacing: '-0.03em', lineHeight: 1, margin: '0 0 6px' }}>
              {p.price}{p.price !== 'Custom' && <sub style={{ fontSize: 16, fontWeight: 500, color: 'var(--text-muted)', verticalAlign: 'baseline' }}>/mo</sub>}
            </p>
            <p style={{ fontSize: 13.5, color: 'var(--text-muted)', margin: '0 0 22px', paddingBottom: 20, borderBottom: '1px solid var(--border-default)' }}>{p.desc}</p>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 11, margin: '0 0 26px', padding: 0, flex: 1 }}>
              {p.features.map(f => (
                <li key={f} style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 13.5, color: 'var(--text-body)' }}>
                  <span style={{ color: 'var(--brand-deep)', flexShrink: 0, display: 'flex' }}><Icon name="check" size={15} stroke={2.25} /></span>{f}
                </li>
              ))}
            </ul>
            <a onClick={() => go && go('pricing')} style={{ display: 'block', textAlign: 'center', padding: 11, borderRadius: 'var(--radius-sm)',
              fontWeight: 600, fontSize: 14, textDecoration: 'none', cursor: 'pointer',
              background: p.featured ? 'var(--ink)' : 'transparent',
              color: p.featured ? '#fff' : 'var(--ink)',
              border: p.featured ? '1px solid transparent' : '1px solid var(--border-default)' }}>
              {p.tier === 'Enterprise' ? 'Contact us' : 'View plan'}
            </a>
          </div>
        ))}
      </div>
      <div style={{ textAlign: 'center', marginTop: 36 }}>
        <a onClick={() => go && go('pricing')} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontWeight: 600, fontSize: 15, color: 'var(--brand-deep)', cursor: 'pointer' }}>
          Compare all plans &amp; add-ons <Icon name="arrow-right" size={15} />
        </a>
      </div>
    </section>
  );
}

function CTA({ onCta }) {
  return (
    <section style={{ padding: '40px var(--gutter) 100px' }}>
      <div data-reveal className="isVisible" style={{ maxWidth: 'var(--container-max)', margin: '0 auto', textAlign: 'center',
        padding: '72px 32px', borderRadius: 'var(--radius-xl)',
        background: 'radial-gradient(ellipse 70% 120% at 50% 0%, var(--brand-soft-2), transparent 70%), var(--off-white)',
        border: '1px solid var(--border-default)' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(28px,3.4vw,46px)', fontWeight: 700,
          color: 'var(--ink)', letterSpacing: '-0.025em', lineHeight: 1.1, margin: '0 0 16px' }}>Ready to win back your time?</h2>
        <p style={{ fontSize: 17, color: 'var(--text-muted)', maxWidth: 460, margin: '0 auto 32px', lineHeight: 1.7 }}>
          Join businesses that handle customer support in half the time with Yippie. No credit card required.
        </p>
        <Button variant="primary" size="lg" iconRight={<Icon name="arrow-right" size={18} />} onClick={onCta}>Request demo</Button>
      </div>
    </section>
  );
}

Object.assign(window, { Pricing, CTA });
