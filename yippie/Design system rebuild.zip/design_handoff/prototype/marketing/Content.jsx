const { Stat, Card, Eyebrow } = window.YippieDesign_488656;
const { Icon } = window;
const ProductMoment_Mockup = window.ProductMockup;

const TRUST = ['Acme BV', 'Nordex', 'Bloom Agency', 'TechCorp', 'Lumen Studio', 'Vela Foods'];

const FEATURES = [
  { icon: 'inbox', title: 'Smart Inbox', desc: 'Emails and WhatsApp auto-scan into draft tickets. Review and approve in one click — no manual write-up.' },
  { icon: 'ticket', title: 'Ticket Management', desc: 'Track, assign, and close requests in one place. SLA alerts fire before anything slips through.' },
  { icon: 'message-square', title: 'Live Chat', desc: 'Embed a chat widget with one line of code. Every conversation lands in a single dashboard.' },
  { icon: 'users', title: 'Contact Management', desc: 'Full customer history — emails, tickets, invoices — visible at a glance. No inbox digging.' },
  { icon: 'activity', title: 'Activity Feed', desc: 'Real-time log of everything in your business. Always know who did what and when.' },
  { icon: 'credit-card', title: 'Billing', desc: 'Send and track invoices without leaving the platform. Support and financials, in sync.' },
];

const STEPS = [
  { n: '01', title: 'Customer sends a message', desc: 'An email or WhatsApp message lands in your Yippie inbox automatically.' },
  { n: '02', title: 'AI drafts the ticket', desc: 'Yippie reads the message and suggests subject, priority, and description.' },
  { n: '03', title: 'You approve in one click', desc: 'Edit if you want, approve — it becomes a real ticket instantly.' },
];

const GROWTH = [
  { icon: 'users', title: 'Unlimited contacts, on every plan', desc: 'From your first customer to your ten-thousandth — your contact limit never changes. No forced upgrade, no surprise cap.' },
  { icon: 'credit-card', title: 'Transparent pricing, no games', desc: 'One flat monthly price. No hidden fees, no per-contact charges. You always know exactly what you pay.' },
  { icon: 'message-square', title: 'A real person, not a black box', desc: 'I’m here when you need me. Not a ticket queue, not a chatbot. A founder who wants to see you succeed.' },
];

const SECTION = { padding: '96px var(--gutter)' };
const HEAD = { maxWidth: 620, margin: '0 auto 56px', textAlign: 'center' };
const TITLE = { fontFamily: 'var(--font-display)', fontSize: 'clamp(28px, 3.4vw, 44px)', fontWeight: 700,
  color: 'var(--ink)', letterSpacing: '-0.025em', lineHeight: 1.12, margin: '14px 0 14px' };
const SUB = { fontSize: 17, color: 'var(--text-muted)', lineHeight: 1.7, margin: 0 };

function SectionHead({ eyebrow, title, sub, dark }) {
  return (
    <div data-reveal className="isVisible" style={HEAD}>
      <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, letterSpacing: '0.02em',
        color: dark ? 'var(--brand)' : 'var(--brand-deep)', margin: 0 }}>// {eyebrow}</p>
      <h2 style={{ ...TITLE, color: dark ? '#fff' : 'var(--ink)' }}>{title}</h2>
      {sub ? <p style={{ ...SUB, color: dark ? 'rgba(255,255,255,0.6)' : 'var(--text-muted)' }}>{sub}</p> : null}
    </div>
  );
}

function FeatureGrid({ items }) {
  return (
    <div style={{ maxWidth: 960, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px 48px' }}>
      {items.map(f => (
        <div key={f.title} className="featureRow" style={{ display: 'flex', gap: 18, padding: 22, borderRadius: 'var(--radius-lg)' }}>
          <div style={{ flexShrink: 0, width: 48, height: 48, borderRadius: 'var(--radius-md)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--brand-soft)',
            color: 'var(--brand-deep)', border: '1px solid var(--brand-ring)' }}>
            <Icon name={f.icon} size={22} />
          </div>
          <div>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 600, color: 'var(--ink)', margin: '0 0 7px' }}>{f.title}</h3>
            <p style={{ fontSize: 14.5, color: 'var(--text-muted)', lineHeight: 1.65, margin: 0 }}>{f.desc}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

function LogoBar() {
  return (
    <section style={{ padding: '8px var(--gutter) 56px', textAlign: 'center' }}>
      <p style={{ fontFamily: 'var(--font-mono)', fontSize: 12, letterSpacing: '0.04em', color: 'var(--text-muted)', margin: '0 0 22px' }}>
        Teams at growing businesses run support on Yippie
      </p>
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '14px 40px', maxWidth: 880, margin: '0 auto' }}>
        {TRUST.map(n => (
          <span key={n} style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 600, color: '#c2cbd6', letterSpacing: '-0.01em' }}>{n}</span>
        ))}
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 600, color: '#c2cbd6',
          border: '1.5px dashed #c2cbd6', borderRadius: 6, padding: '2px 10px', opacity: 0.6 }}>[Your Company]</span>
      </div>
    </section>
  );
}

function Stats() {
  const stats = [
    { value: '10h+', label: 'saved per week on average' },
    { value: '< 2 min', label: 'average ticket response time' },
    { value: '6', label: 'modules, one platform' },
  ];
  return (
    <section style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '24px var(--gutter) 8px',
      display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 24 }}>
      {stats.map(s => <div key={s.label} style={{ padding: 20 }}><Stat value={s.value} label={s.label} /></div>)}
    </section>
  );
}

function Features() {
  return (
    <section id="features" style={{ ...SECTION, scrollMarginTop: 80 }}>
      <SectionHead eyebrow="Features" title="Everything your support team needs"
        sub="One platform for inbox, tickets, live chat, contacts, billing, and activity. Stop juggling tools." />
      <FeatureGrid items={FEATURES} />
    </section>
  );
}

function HowItWorks() {
  return (
    <section id="how-it-works" style={{ ...SECTION, scrollMarginTop: 80, background: 'var(--off-white)', borderBlock: '1px solid var(--border-default)' }}>
      <SectionHead eyebrow="How it works" title="From email to resolved — in seconds"
        sub="Yippie's AI reads every incoming message and does the write-up for you." />
      <div style={{ maxWidth: 940, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 32, position: 'relative' }}>
        {STEPS.map(s => (
          <div key={s.n} style={{ textAlign: 'center' }}>
            <div style={{ width: 54, height: 54, margin: '0 auto 18px', borderRadius: '50%', background: '#fff',
              border: '1px solid var(--border-default)', boxShadow: 'var(--shadow-sm)', display: 'flex',
              alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 16, color: 'var(--brand-deep)' }}>{s.n}</div>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 600, color: 'var(--ink)', margin: '0 0 8px' }}>{s.title}</h3>
            <p style={{ fontSize: 14.5, color: 'var(--text-muted)', lineHeight: 1.65, margin: 0 }}>{s.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function ProductMoment() {
  return (
    <section id="modules" className="bgDotsDark" style={{ background: 'var(--dark)', color: '#fff', padding: '100px var(--gutter)', textAlign: 'center', scrollMarginTop: 0 }}>
      <SectionHead dark eyebrow="One workspace" title="Everything in one place"
        sub="Inbox, tickets, contacts, and pipeline share the same screen — so nothing falls through the cracks and every reply has full context." />
      <div data-reveal className="isVisible"><ProductMoment_Mockup wide /></div>
    </section>
  );
}

function GrowthPartner() {
  return (
    <section style={{ ...SECTION, background: 'var(--off-white)', borderBlock: '1px solid var(--border-default)' }}>
      <SectionHead eyebrow="Growth Partner" title="When you grow, I grow." />
      <FeatureGrid items={GROWTH} />
    </section>
  );
}

Object.assign(window, { LogoBar, Stats, Features, HowItWorks, ProductMoment, GrowthPartner });
