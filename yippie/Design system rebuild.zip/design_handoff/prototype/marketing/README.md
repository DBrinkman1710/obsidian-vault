# Marketing Site UI Kit — getyippie.com

A faithful recreation of the Yippie marketing site (`apps/web`, Next.js 14 + Tailwind v3). Composes the design-system primitives (`Button`, `Badge`, `Card`, `Eyebrow`, `Stat`, `Toggle`, `Input`, `Avatar`) over the real tokens in `styles.css`.

## Surfaces
- **icons.jsx** — `Icon` helper that renders lucide glyphs as inline SVG.
- **Nav.jsx** — sticky nav + working `SignUpModal` (Name / Email / Company / Phone).
- **Hero.jsx** — split hero with the rotated browser-chrome app mockup and brand glow.
- **Content.jsx** — logo bar, stats band, features grid, "how it works" steps, the dark inbox product moment, CTA, footer.
- **Pricing.jsx** — three plans with a working monthly/annual toggle (−20%).
- **index.html** — composes the full page; the "Sign up" button opens the modal.

## Notes
- Real page source: `apps/web/src/app/page.tsx`. Section order matches it exactly:
  Nav → Hero → Logo bar → Stats → Features → How it works → Product moment → Pricing → CTA → Footer.
- Icons are lucide (the site uses `lucide-react`). No emoji anywhere.
- Open `index.html` to interact: toggle pricing, open the sign-up modal, submit it.
