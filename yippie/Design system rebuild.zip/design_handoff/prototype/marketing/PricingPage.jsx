const { Button } = window.YippieDesign_488656;
const { Icon } = window;

/* Config-driven — mirrors apps/web/src/lib/config.ts (PLAN_LIMITS / MODULE_PRICES).
   Every plan's feature list is exactly 6 rows so the cards stay equal height. */
const PLANS = [
  { tier: 'Founder', monthly: 9, annual: 97, tagline: 'Founding Member — first 5 spots', founding: true,
    included: ['Inbox', 'Contacts', '2 users', 'Unlimited contacts', '500 AI scans/mo', 'Add-ons à la carte'] },
  { tier: 'Starter', monthly: 19, annual: 205, tagline: 'For small teams',
    included: ['Inbox', 'Contacts', '5 users', 'Unlimited contacts', '2,000 AI scans/mo', 'Add-ons à la carte'] },
  { tier: 'Growth', monthly: 49, annual: 529, tagline: 'For growing businesses', featured: true,
    included: ['Inbox', 'Contacts', '10 users', 'Unlimited contacts', '10,000 AI scans/mo', 'Add-ons à la carte'] },
  { tier: 'Enterprise', monthly: null, annual: null, tagline: 'Dedicated growth partnership', enterprise: true,
    included: ['Everything in Growth', 'Tickets + AI + Calendar', 'Kanban + Email tracking', 'Unlimited users', 'Unlimited AI scans', 'Dedicated support'] },
];

const ADDONS = [
  { icon: 'clipboard-list', name: 'Tickets', desc: 'Track, assign, and close requests with SLA alerts.', price: 15 },
  { icon: 'sparkles', name: 'AI', desc: 'Auto-draft tickets and replies from incoming messages.', price: 19 },
  { icon: 'calendar', name: 'Calendar + Booking', desc: 'Share booking links and manage appointments.', price: 12 },
  { icon: 'kanban', name: 'Kanban', desc: 'Visual pipeline boards to move work through stages.', price: 12 },
  { icon: 'mail-check', name: 'Email tracking', desc: 'See when your sent emails are delivered and opened.', price: 9 },
];

const FAQS = [
  { q: 'Why unlimited contacts on every plan?', a: 'Your contact list growing shouldn’t be a reason to pay more. I removed contact limits entirely — plans differ by team size (users) and AI processing volume (scans per month), not by how many customers you have.' },
  { q: 'Can I change my plan?', a: 'Yes — upgrade or downgrade at any time. Changes take effect immediately and I prorate the difference on your next invoice.' },
  { q: 'Are add-on prices per user or per workspace?', a: 'Add-ons are priced per workspace, not per user. One flat monthly price unlocks the feature for your whole team.' },
  { q: 'Is there a free trial?', a: 'We offer a guided demo and a trial workspace so you can try Yippie with your real inbox before committing. Talk to us to get set up.' },
];

const PTITLE = { fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--ink)', letterSpacing: '-0.025em' };

function PricingPage({ onDemo }) {
  const [annual, setAnnual] = React.useState(false);
  const [openFaq, setOpenFaq] = React.useState(0);
  return (
    <React.Fragment>
      {/* Hero */}
      <section className="bgGrid" style={{ textAlign: 'center', padding: '110px var(--gutter) 40px', background: '#fff' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: '#fff', border: '1px solid var(--border-default)',
          boxShadow: 'var(--shadow-sm)', borderRadius: 'var(--radius-full)', padding: '6px 14px', fontFamily: 'var(--font-mono)',
          fontSize: 12, fontWeight: 500, color: 'var(--text-muted)', marginBottom: 24 }}>
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--brand)', boxShadow: '0 0 0 4px var(--brand-soft)' }} />
          Transparent pricing, no games
        </div>
        <h1 style={{ ...PTITLE, fontSize: 'clamp(36px,5vw,60px)', lineHeight: 1.04, margin: '0 0 18px' }}>Scale without limits.</h1>
        <p style={{ fontSize: 18, color: 'var(--text-muted)', lineHeight: 1.7, maxWidth: 560, margin: '0 auto 30px' }}>
          Every plan includes unlimited contacts. Pay for the team size and AI power you need — add modules à la carte as you grow. No hidden fees, cancel anytime.
        </p>
        {/* toggle */}
        <div style={{ display: 'inline-flex', background: 'var(--off-white)', border: '1px solid var(--border-default)',
          borderRadius: 'var(--radius-full)', padding: 4, gap: 4 }}>
          {[['Monthly', false], ['Annual', true]].map(([lbl, val]) => (
            <button key={lbl} onClick={() => setAnnual(val)} style={{ display: 'inline-flex', alignItems: 'center', gap: 8,
              padding: '8px 18px', borderRadius: 'var(--radius-full)', border: 'none', cursor: 'pointer',
              fontFamily: 'var(--font-body)', fontSize: 14, fontWeight: 600,
              background: annual === val ? 'var(--ink)' : 'transparent', color: annual === val ? '#fff' : 'var(--text-subtle)' }}>
              {lbl}{lbl === 'Annual' && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 600,
                color: annual === val ? '#fff' : 'var(--brand-deep)' }}>Save 10%</span>}
            </button>
          ))}
        </div>
      </section>

      {/* Plans */}
      <section style={{ padding: '40px var(--gutter) 80px' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, alignItems: 'stretch' }}>
          {PLANS.map(p => (
            <div key={p.tier} className="priceCard" style={{ position: 'relative', padding: '30px 26px', borderRadius: 'var(--radius-lg)',
              background: '#fff', display: 'flex', flexDirection: 'column',
              border: p.featured ? '1.5px solid var(--brand)' : '1px solid var(--border-default)',
              boxShadow: p.featured ? 'var(--shadow-md)' : 'none' }}>
              {(p.featured || p.founding) && (
                <span style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', background: 'var(--ink)', color: '#fff',
                  fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase',
                  padding: '5px 12px', borderRadius: 'var(--radius-full)', whiteSpace: 'nowrap' }}>{p.featured ? 'Most popular' : 'Founding Member'}</span>
              )}
              <p style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--brand-deep)', margin: '0 0 12px' }}>{p.tier}</p>
              <p style={{ ...PTITLE, fontSize: 40, lineHeight: 1, margin: '0 0 4px' }}>
                {p.enterprise ? 'Custom' : <React.Fragment>€{annual ? p.annual : p.monthly}<sub style={{ fontSize: 15, fontWeight: 500, color: 'var(--text-muted)', verticalAlign: 'baseline' }}>{annual ? '/yr' : '/mo'}</sub></React.Fragment>}
              </p>
              <p style={{ fontFamily: 'var(--font-mono)', fontSize: 11.5, color: annual && !p.enterprise ? 'var(--brand-deep)' : 'var(--text-muted)', margin: '0 0 14px', minHeight: 16 }}>
                {p.enterprise ? 'let’s talk' : annual ? `10% off — was €${p.monthly * 12}/yr` : 'billed monthly'}
              </p>
              <p style={{ fontSize: 13.5, color: 'var(--text-muted)', margin: '0 0 20px', paddingBottom: 18, borderBottom: '1px solid var(--border-default)' }}>{p.tagline}</p>
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 11, margin: '0 0 24px', padding: 0, flex: 1 }}>
                {p.included.map(f => (
                  <li key={f} style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 13.5, color: 'var(--text-body)' }}>
                    <span style={{ color: 'var(--brand-deep)', flexShrink: 0, display: 'flex' }}><Icon name="check" size={15} stroke={2.25} /></span>{f}
                  </li>
                ))}
              </ul>
              <button onClick={onDemo} style={{ padding: 11, borderRadius: 'var(--radius-sm)', fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 14, cursor: 'pointer',
                background: p.featured ? 'var(--ink)' : 'transparent', color: p.featured ? '#fff' : 'var(--ink)',
                border: p.featured ? '1px solid transparent' : '1px solid var(--border-default)' }}>{p.enterprise ? 'Contact us' : 'Request demo'}</button>
            </div>
          ))}
        </div>
      </section>

      {/* Add-ons */}
      <section style={{ padding: '80px var(--gutter)', background: 'var(--off-white)', borderBlock: '1px solid var(--border-default)' }}>
        <div style={{ textAlign: 'center', maxWidth: 620, margin: '0 auto 48px' }}>
          <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, color: 'var(--brand-deep)', margin: 0 }}>// Add-ons</p>
          <h2 style={{ ...PTITLE, fontSize: 'clamp(26px,3vw,38px)', margin: '12px 0' }}>Add the features you need</h2>
          <p style={{ fontSize: 16, color: 'var(--text-muted)', lineHeight: 1.7, margin: 0 }}>Start with the core and switch on any module à la carte — one flat price per workspace, per month.</p>
        </div>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 14 }}>
          {ADDONS.map(a => (
            <div key={a.name} style={{ background: '#fff', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-md)', padding: 22 }}>
              <div style={{ width: 44, height: 44, borderRadius: 'var(--radius-md)', background: 'var(--brand-soft)', color: 'var(--brand-deep)',
                border: '1px solid var(--brand-ring)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}><Icon name={a.icon} size={20} /></div>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, color: 'var(--ink)', margin: '0 0 6px' }}>{a.name}</h3>
              <p style={{ fontSize: 12.5, color: 'var(--text-muted)', lineHeight: 1.55, margin: '0 0 14px' }}>{a.desc}</p>
              <p style={{ ...PTITLE, fontSize: 24, margin: 0 }}>€{a.price}<span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 500, color: 'var(--text-muted)' }}>/mo</span></p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section style={{ padding: '80px var(--gutter)' }}>
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, color: 'var(--brand-deep)', margin: 0 }}>// FAQ</p>
          <h2 style={{ ...PTITLE, fontSize: 'clamp(26px,3vw,38px)', margin: '12px 0 0' }}>Questions, answered</h2>
        </div>
        <div style={{ maxWidth: 720, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 12 }}>
          {FAQS.map((item, i) => (
            <div key={item.q} style={{ border: '1px solid var(--border-default)', borderRadius: 'var(--radius-md)', background: '#fff', overflow: 'hidden' }}>
              <button onClick={() => setOpenFaq(openFaq === i ? -1 : i)} style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                gap: 16, padding: '18px 22px', border: 'none', background: 'transparent', cursor: 'pointer', textAlign: 'left',
                fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 600, color: 'var(--ink)' }}>
                {item.q}<span style={{ fontFamily: 'var(--font-mono)', fontSize: 20, color: 'var(--brand-deep)', flexShrink: 0 }}>{openFaq === i ? '−' : '+'}</span>
              </button>
              {openFaq === i && <p style={{ margin: 0, padding: '0 22px 20px', fontSize: 14.5, color: 'var(--text-muted)', lineHeight: 1.7 }}>{item.a}</p>}
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: '40px var(--gutter) 100px' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', textAlign: 'center', padding: '72px 32px', borderRadius: 'var(--radius-xl)',
          background: 'radial-gradient(ellipse 70% 120% at 50% 0%, var(--brand-soft-2), transparent 70%), var(--off-white)', border: '1px solid var(--border-default)' }}>
          <h2 style={{ ...PTITLE, fontSize: 'clamp(28px,3.4vw,42px)', lineHeight: 1.1, margin: '0 0 16px' }}>Not sure which plan fits?</h2>
          <p style={{ fontSize: 17, color: 'var(--text-muted)', maxWidth: 460, margin: '0 auto 32px', lineHeight: 1.7 }}>Tell me about your team and I’ll help you pick the right plan and add-ons. No pressure, no credit card.</p>
          <Button variant="primary" size="lg" iconRight={<Icon name="arrow-right" size={18} />} onClick={onDemo}>Talk to us</Button>
        </div>
      </section>
    </React.Fragment>
  );
}

window.PricingPage = PricingPage;
