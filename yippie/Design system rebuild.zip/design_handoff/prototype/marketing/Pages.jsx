const { Button, Stat, Avatar, Badge } = window.YippieDesign_488656;
const { Icon } = window;

/* ── About — Diederik's founder story (first person) ──────────── */
const JOURNEY = [
  { co: 'Bol.com', role: 'High-volume consumer support', icon: 'inbox' },
  { co: 'HeatTransformers', role: 'Heat-pump installation planning', icon: 'calendar' },
  { co: 'Medspace', role: 'Scheduling software for hospital departments', icon: 'clipboard-list' },
];
const EXTREMES = [
  { n: '01', title: 'Shared mailbox chaos', desc: 'Teams drowning in a shared Outlook or WhatsApp inbox — nobody sure who was picking up which thread, things slipping through daily.' },
  { n: '02', title: 'Enterprise bloat', desc: 'Over-engineered platforms like Zoho and Atlassian: heavy, hyper-complex, and packed with features 90% of small businesses will never touch.' },
];
const PHILOSOPHY = [
  { title: 'Easy to learn', desc: 'Zero training required. Your team is up and running in under five minutes.', icon: 'bolt' },
  { title: 'Pay for what you use', desc: 'No bloated enterprise pricing. Add modules à la carte, only when you need them.', icon: 'credit-card' },
  { title: 'Grows with your business', desc: 'Unlimited contacts on every plan. Unlock complexity only when your team actually needs it.', icon: 'trending-up' },
];

function AboutPage({ onDemo }) {
  return (
    <React.Fragment>
      {/* Hero */}
      <section className="bgGrid" style={{ textAlign: 'center', padding: '110px var(--gutter) 50px', background: '#fff' }}>
        <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, color: 'var(--brand-deep)', margin: '0 0 14px' }}>// About</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'clamp(34px,4.6vw,56px)', letterSpacing: '-0.03em', lineHeight: 1.06, color: 'var(--ink)', margin: '0 auto 18px', maxWidth: 720 }}>
          I&rsquo;m an engineer who got tired of watching support break.
        </h1>
        <p style={{ fontSize: 18, color: 'var(--text-muted)', lineHeight: 1.7, maxWidth: 560, margin: '0 auto 28px' }}>
          I&rsquo;m Diederik — an industrial engineer with a slightly obsessive habit of optimising things. Yippie is the tool I always wished existed.
        </p>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12, padding: '8px 8px 8px 8px', borderRadius: 'var(--radius-full)', border: '1px solid var(--border-default)', background: '#fff', boxShadow: 'var(--shadow-sm)' }}>
          <Avatar name="Diederik Brinkman" size={36} tone="brand" />
          <span style={{ paddingRight: 14, fontSize: 13.5, color: 'var(--text-subtle)' }}><strong style={{ color: 'var(--ink)' }}>Diederik Brinkman</strong> · Founder</span>
        </div>
      </section>

      {/* Story */}
      <section style={{ padding: '70px var(--gutter)', background: 'var(--off-white)', borderBlock: '1px solid var(--border-default)' }}>
        <div style={{ maxWidth: 760, margin: '0 auto' }}>
          <p style={{ fontSize: 17.5, color: 'var(--text-body)', lineHeight: 1.8, margin: '0 0 20px' }}>
            For years I worked the frontlines of customer service and planning — high-volume consumer support at <strong>Bol.com</strong>, complex installation scheduling at <strong>HeatTransformers</strong>, and critical software support for hospital departments at <strong>Medspace</strong>.
          </p>
          <p style={{ fontSize: 17.5, color: 'var(--text-body)', lineHeight: 1.8, margin: '0 0 32px' }}>
            Different industries, same two extremes — every single time:
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 36 }}>
            {EXTREMES.map(e => (
              <div key={e.n} style={{ background: '#fff', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-md)', padding: 24 }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, color: 'var(--brand-deep)' }}>{e.n}</span>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 600, color: 'var(--ink)', margin: '8px 0 8px' }}>{e.title}</h3>
                <p style={{ fontSize: 14.5, color: 'var(--text-muted)', lineHeight: 1.65, margin: 0 }}>{e.desc}</p>
              </div>
            ))}
          </div>
          <p style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(22px,2.6vw,30px)', fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--ink)', lineHeight: 1.3, margin: 0 }}>
            I knew it could be better. As an engineer, I knew <span style={{ color: 'var(--brand-deep)' }}>I</span> could build better. So I did — I built Yippie.
          </p>
        </div>
      </section>

      {/* Where I've been */}
      <section style={{ padding: '70px var(--gutter)' }}>
        <div style={{ textAlign: 'center', marginBottom: 36 }}>
          <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, color: 'var(--brand-deep)', margin: 0 }}>// The frontlines</p>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(24px,3vw,36px)', fontWeight: 700, letterSpacing: '-0.025em', color: 'var(--ink)', margin: '12px 0 0' }}>Where this came from</h2>
        </div>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 }}>
          {JOURNEY.map(j => (
            <div key={j.co} style={{ background: '#fff', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-md)', padding: 26 }}>
              <div style={{ width: 44, height: 44, borderRadius: 'var(--radius-md)', background: 'var(--brand-soft)', color: 'var(--brand-deep)', border: '1px solid var(--brand-ring)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}><Icon name={j.icon} size={20} /></div>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 600, color: 'var(--ink)', margin: '0 0 6px' }}>{j.co}</h3>
              <p style={{ fontSize: 14, color: 'var(--text-muted)', lineHeight: 1.6, margin: 0 }}>{j.role}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Philosophy */}
      <section style={{ padding: '70px var(--gutter)', background: 'var(--off-white)', borderBlock: '1px solid var(--border-default)' }}>
        <div style={{ textAlign: 'center', maxWidth: 620, margin: '0 auto 44px' }}>
          <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, color: 'var(--brand-deep)', margin: 0 }}>// The philosophy</p>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(26px,3vw,40px)', fontWeight: 700, letterSpacing: '-0.025em', color: 'var(--ink)', margin: '12px 0 12px' }}>Customer support, made easy.</h2>
          <p style={{ fontSize: 17, color: 'var(--text-muted)', lineHeight: 1.7, margin: 0 }}>One simple promise: take back your time. I strip away the admin clutter so you can focus on what matters — your customers.</p>
        </div>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20 }}>
          {PHILOSOPHY.map(v => (
            <div key={v.title} style={{ background: '#fff', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-md)', padding: 26 }}>
              <div style={{ width: 48, height: 48, borderRadius: 'var(--radius-md)', background: 'var(--brand-soft)', color: 'var(--brand-deep)', border: '1px solid var(--brand-ring)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}><Icon name={v.icon} size={22} /></div>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 600, color: 'var(--ink)', margin: '0 0 8px' }}>{v.title}</h3>
              <p style={{ fontSize: 14.5, color: 'var(--text-muted)', lineHeight: 1.65, margin: 0 }}>{v.desc}</p>
            </div>
          ))}
        </div>
        <p style={{ textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: 14, color: 'var(--brand-deep)', margin: '36px 0 0' }}>No bloat. No missed threads. Just fast, minimalist support.</p>
      </section>

      {/* CTA */}
      <section style={{ padding: '40px var(--gutter) 100px' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', textAlign: 'center', padding: '72px 32px', borderRadius: 'var(--radius-xl)',
          background: 'radial-gradient(ellipse 70% 120% at 50% 0%, var(--brand-soft-2), transparent 70%), var(--off-white)', border: '1px solid var(--border-default)' }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'clamp(28px,3.4vw,42px)', letterSpacing: '-0.025em', color: 'var(--ink)', margin: '0 0 16px' }}>Want to see what I built?</h2>
          <p style={{ fontSize: 17, color: 'var(--text-muted)', maxWidth: 460, margin: '0 auto 32px', lineHeight: 1.7 }}>Request a demo and I&rsquo;ll walk you through Yippie myself — in under twenty minutes.</p>
          <Button variant="primary" size="lg" iconRight={<Icon name="arrow-right" size={18} />} onClick={onDemo}>Request demo</Button>
        </div>
      </section>
    </React.Fragment>
  );
}

/* ── Blog ─────────────────────────────────────────────────────── */
const POSTS = [
  { tag: 'AI', title: '5 ways AI saves SMB customer service time', excerpt: 'From auto-drafting tickets to triaging your inbox — the concrete ways AI gives small teams hours back every week.', date: 'Jun 12, 2026', read: '6 min' },
  { tag: 'Playbook', title: 'How to reduce customer service response time', excerpt: 'A practical playbook for getting under the 2-minute mark without burning out your team.', date: 'Jun 4, 2026', read: '5 min' },
  { tag: 'Growth', title: 'Why I made contacts unlimited on every plan', excerpt: 'Charging more as your customer list grows is backwards. Here&rsquo;s the thinking behind Yippie&rsquo;s pricing.', date: 'May 28, 2026', read: '4 min' },
];

function BlogPage() {
  return (
    <React.Fragment>
      <section className="bgGrid" style={{ textAlign: 'center', padding: '110px var(--gutter) 50px', background: '#fff' }}>
        <p style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, color: 'var(--brand-deep)', margin: '0 0 14px' }}>// Blog</p>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'clamp(34px,4.6vw,56px)', letterSpacing: '-0.03em', color: 'var(--ink)', margin: '0 0 18px' }}>From the Yippie blog</h1>
        <p style={{ fontSize: 18, color: 'var(--text-muted)', lineHeight: 1.7, maxWidth: 540, margin: '0 auto' }}>Notes on customer service, AI, and giving small teams their time back.</p>
      </section>
      <section style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '20px var(--gutter) 100px', display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20 }}>
        {POSTS.map(p => (
          <a key={p.title} href="#" className="priceCard" style={{ display: 'flex', flexDirection: 'column', background: '#fff', border: '1px solid var(--border-default)',
            borderRadius: 'var(--radius-md)', overflow: 'hidden' }}>
            <div className="bgDots" style={{ height: 150, background: 'var(--off-white)', borderBottom: '1px solid var(--border-default)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 600, color: 'var(--brand-deep)', background: 'var(--brand-soft)', border: '1px solid var(--brand-ring)', padding: '4px 10px', borderRadius: 'var(--radius-full)' }}>{p.tag}</span>
            </div>
            <div style={{ padding: 22, display: 'flex', flexDirection: 'column', flex: 1 }}>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 600, color: 'var(--ink)', lineHeight: 1.25, margin: '0 0 10px' }}>{p.title}</h3>
              <p style={{ fontSize: 14, color: 'var(--text-muted)', lineHeight: 1.6, margin: '0 0 18px', flex: 1 }}>{p.excerpt}</p>
              <p style={{ fontFamily: 'var(--font-mono)', fontSize: 11.5, color: 'var(--text-muted)', margin: 0 }}>{p.date} · {p.read} read</p>
            </div>
          </a>
        ))}
      </section>
    </React.Fragment>
  );
}

Object.assign(window, { AboutPage, BlogPage });
